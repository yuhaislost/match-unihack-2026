# Authentication & Authorization System — Implementation Plan

## Context

The Match app has a fully defined Prisma schema (User, PlayerProfile, MerchantProfile with Role enum), tRPC infrastructure with a placeholder context (`userId: "user_123"`), and Supabase project credentials in `.env` — but **zero auth implementation**. No Supabase packages are installed, no middleware exists, no route groups exist, and no auth pages exist. This plan builds the complete auth and authorization system from scratch.

---

## Step 0: Supabase Dashboard Setup (Manual, Pre-requisite)

1. **Get service role key**: Dashboard → Project Settings → API → `service_role` secret key
2. **Configure Google OAuth**:
   - Google Cloud Console → OAuth 2.0 Client ID (Web Application)
   - Redirect URI: `https://kyntyznykmghojnkypnd.supabase.co/auth/v1/callback`
   - Paste Client ID + Secret in Supabase Dashboard → Auth → Providers → Google
3. **Configure Apple OAuth**:
   - Apple Developer → Services ID with Sign In with Apple
   - Redirect URL: `https://kyntyznykmghojnkypnd.supabase.co/auth/v1/callback`
   - Paste Services ID, Team ID, Key ID, private key in Supabase → Auth → Providers → Apple
4. **Set redirect URLs**: Dashboard → Auth → URL Configuration:
   - Site URL: `http://localhost:3000`
   - Redirect URLs: `http://localhost:3000/auth/callback`
5. **Disable email auth**: Dashboard → Auth → Providers → Email → disable

---

## Step 1: Install Dependencies

```bash
npm install @supabase/supabase-js @supabase/ssr
```

- `@supabase/supabase-js` — core Supabase client SDK
- `@supabase/ssr` — cookie-based auth helpers for Next.js SSR

---

## Step 2: Environment Variables

Add to `.env`:
```
SUPABASE_SERVICE_ROLE_KEY=<from dashboard>
```

Already present: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY`

---

## Step 3: Supabase Adapter — Two Files

### `src/lib/supabase.ts` (server-only)

Imports `'server-only'`. Exports two factory functions:

- **`createServerClient(cookieStore)`** — Uses `@supabase/ssr` `createServerClient` with cookie adapter mapped to Next.js `cookies()` return value. Uses the public anon key. Respects user session (RLS-aware).
- **`createServiceRoleClient()`** — Uses `@supabase/supabase-js` `createClient` with `SUPABASE_SERVICE_ROLE_KEY`. Bypasses RLS. Used sparingly (onboarding user creation, setting `app_metadata`).

### `src/lib/supabase-browser.ts` (client-safe)

Exports `createBrowserClient()` using `@supabase/ssr`'s browser client factory with the public anon key. This is the only Supabase import safe for `'use client'` files.

---

## Step 4: tRPC Context & Auth Middleware — `src/trpc/init.ts`

Replace the hardcoded placeholder with real auth:

**`createTRPCContext({ headers })`:**
1. Create a Supabase server client from the request cookies (extracted from headers)
2. Call `supabase.auth.getUser()` to verify the JWT
3. If valid user, look up the app `User` record via `prisma.user.findUnique({ where: { authUserId } })`
4. Return `{ user: appUser | null, supabaseUser: supabaseUser | null }`

**New middleware exports:**

| Procedure | Auth Check |
|---|---|
| `baseProcedure` | None (public) |
| `protectedProcedure` | `ctx.user` must exist and `deletedAt` must be null, else throw `UNAUTHORIZED`/`FORBIDDEN` |
| `onboardingProcedure` | `ctx.supabaseUser` must exist (user may not have a DB record yet) |
| `playerProcedure` | Extends `protectedProcedure` + `ctx.user.role === 'PLAYER'` |
| `merchantProcedure` | Extends `protectedProcedure` + `ctx.user.role === 'MERCHANT'` |

---

## Step 5: tRPC Client Update — `src/trpc/client.tsx`

Ensure the `httpBatchLink` sends cookies (same-origin does this by default, but verify `credentials: 'include'` is set). No `Authorization` header needed — `@supabase/ssr` uses cookies.

---

## Step 6: Auth Callback — `src/app/auth/callback/route.ts`

GET handler that:
1. Reads `code` from query params
2. Exchanges code for session via `supabase.auth.exchangeCodeForSession(code)`
3. Looks up User record by `authUserId`
4. Redirects based on state:
   - No User record → `/onboarding/role-select`
   - User exists, `deletedAt` set → `/account-deactivated`
   - User exists, no profile → `/onboarding/player-profile` or `/onboarding/merchant-profile`
   - User exists, profile complete → `/explore` (player) or `/dashboard` (merchant)

---

## Step 7: Next.js Middleware — `middleware.ts` (project root)

Responsibilities:
1. **Refresh tokens** — Call `supabase.auth.getUser()` which triggers JWT refresh via `@supabase/ssr` cookie handling
2. **Route protection:**
   - Public routes (`/login`, `/auth/callback`): allow. If authenticated and on `/login`, redirect to role-based home.
   - Onboarding routes (`/onboarding/*`): require authentication only
   - Player routes (`/explore`, `/sessions`, `/profile`): require auth + PLAYER role
   - Merchant routes (`/dashboard`, `/courts`, `/upsells`): require auth + MERCHANT role
   - Unauthenticated → redirect to `/login`

**Role in middleware:** Store role in Supabase `app_metadata.role` (set during onboarding via service role client). Middleware reads `user.app_metadata.role` — no DB call needed on Edge runtime.

**Cookie handling:** Create `NextResponse`, proxy cookie get/set through it for token refresh persistence.

---

## Step 8: Auth Service — `src/lib/services/auth.ts`

Server-only. Returns `ServiceResult<T>`. Functions:

- `findUserByAuthId(authUserId)` → User | null
- `createUser({ authUserId, email, displayName, avatarUrl, role })` → User
- `createPlayerProfile({ userId, skillLevel, bio?, latitude?, longitude? })` → PlayerProfile
- `createMerchantProfile({ userId, businessName })` → MerchantProfile
- `isOnboardingComplete(userId)` → boolean

---

## Step 9: Onboarding Use-Case — `src/use-cases/complete-onboarding.ts`

Server-only. Orchestrates:
1. Create User record (idempotent — skip if exists)
2. Set `app_metadata.role` in Supabase via service role client
3. Create PlayerProfile or MerchantProfile
4. Create default NotificationPreference

Handles interrupted onboarding: if User exists but profile is missing, picks up from where it left off.

---

## Step 10: Onboarding Router — `src/trpc/routers/onboarding.ts`

Uses `onboardingProcedure` (requires Supabase user, not app User).

| Procedure | Input | Description |
|---|---|---|
| `onboarding.getStatus` | — | Returns onboarding state |
| `onboarding.selectRole` | `{ role }` | Creates User, sets `app_metadata` |
| `onboarding.completePlayerProfile` | `{ skillLevel, bio?, lat?, lng? }` | Creates PlayerProfile |
| `onboarding.completeMerchantProfile` | `{ businessName }` | Creates MerchantProfile |

Register in `src/trpc/routers/_app.ts`.

---

## Step 11: Zod Schemas — `src/schemas/onboarding.ts`

- `selectRoleSchema` — `{ role: z.enum(['PLAYER', 'MERCHANT']) }`
- `completePlayerProfileSchema` — `{ skillLevel, bio?, latitude?, longitude? }`
- `completeMerchantProfileSchema` — `{ businessName }`

---

## Step 12: Auth Hook — `src/hooks/use-auth.ts`

`'use client'` hook using `createBrowserClient()`:

- **State:** `user`, `loading`
- **Listeners:** `onAuthStateChange` for login/logout/token refresh
- **Actions:** `signInWithGoogle()`, `signInWithApple()`, `signOut()`

---

## Step 13: Auth Pages & Route Group Layouts

### Auth pages (`src/app/(auth)/`)

| Page | Component | Description |
|---|---|---|
| `(auth)/layout.tsx` | Server | Minimal centered layout with logo |
| `(auth)/login/page.tsx` | Server → renders client form | Social login page |
| `(auth)/onboarding/role-select/page.tsx` | Server → renders client form | Player vs Merchant selection |
| `(auth)/onboarding/player-profile/page.tsx` | Server → renders client form | Skill level, bio, location |
| `(auth)/onboarding/merchant-profile/page.tsx` | Server → renders client form | Business name |

### Client components (`src/components/auth/`)

| File | Description |
|---|---|
| `login-form.tsx` | Google + Apple sign-in buttons |
| `role-select-form.tsx` | Player/Merchant cards |
| `player-profile-form.tsx` | Skill level, bio, location form |
| `merchant-profile-form.tsx` | Business name form |

### Role-based route group layouts

| Layout | Guards |
|---|---|
| `src/app/(player)/layout.tsx` | Auth → role (PLAYER) → onboarding check → render with bottom nav |
| `src/app/(merchant)/layout.tsx` | Auth → role (MERCHANT) → onboarding check → render with nav |

### Stub pages

- `(player)/explore/page.tsx`, `(player)/sessions/page.tsx`, `(player)/profile/page.tsx`
- `(merchant)/dashboard/page.tsx`, `(merchant)/courts/page.tsx`, `(merchant)/upsells/page.tsx`

### Root page (`src/app/page.tsx`)

Redirect to `/login` (unauthenticated) or role-based home (authenticated).

---

## Step 14: RLS Policies — Prisma Migration

Create via `npx prisma migrate dev --name add-rls-policies`.

**Policy patterns:**

| Table Group | SELECT | INSERT/UPDATE |
|---|---|---|
| `users` | Own record only | Own record only |
| `player_profiles`, `merchant_profiles` | Public read | Own record only |
| `venues`, `courts`, `court_availabilities`, `upsell_items` | Public read | Owning merchant only |
| `sessions`, `session_players` | Participants only | Creator/relevant player |
| `quick_match_queue_entries`, `match_requests`, `decline_cooldowns` | Own entries | Own entries |
| `venue_proposals`, `venue_proposal_votes` | Session participants | Session participants |
| `bookings`, `booking_player_shares`, `booking_upsells` | Participants | System (service role) |
| `chat_rooms`, `chat_participants`, `chat_messages`, `message_read_receipts` | Room participants | Room participants |
| `venue_reviews`, `player_ratings` | Public read | Own reviews/ratings |
| `notifications`, `notification_preferences` | Own only | Own only |
| `system_config` | Authenticated read | None (admin via service role) |
| `merchant_payouts` | Owning merchant | System (service role) |

Enable RLS on all 24 tables.

---

## Implementation Batches

| Batch | Files | Testable? |
|---|---|---|
| **1. Foundation** | Install deps, `.env`, `supabase.ts`, `supabase-browser.ts`, update `init.ts` | tRPC context logs real auth state |
| **2. Routing** | `auth/callback/route.ts`, `middleware.ts`, update `client.tsx` | OAuth flow redirects work |
| **3. Backend** | `schemas/onboarding.ts`, `services/auth.ts`, `use-cases/complete-onboarding.ts`, `routers/onboarding.ts`, update `_app.ts` | Onboarding mutations work |
| **4. UI** | `use-auth.ts`, all pages + components under `(auth)/`, `(player)/`, `(merchant)/`, update `page.tsx` | Full login → onboarding → home flow |
| **5. Hardening** | RLS migration | Verify Prisma still works (service role bypasses RLS) |

---

## Edge Cases

- **Interrupted onboarding**: Auth callback checks state; `selectRole` mutation is idempotent; layouts re-check onboarding completeness
- **JWT expiry**: `@supabase/ssr` auto-refreshes in both browser client and middleware — no custom logic needed
- **Soft-deleted users**: Checked in both auth callback and `protectedProcedure` middleware → `FORBIDDEN`
- **Role in middleware (Edge runtime)**: Stored in `app_metadata.role`, readable from JWT without DB call

---

## Verification Checklist

1. Visit `/login` → Google OAuth → callback → role select → profile → home page
2. Visit `/explore` while logged out → redirected to `/login`
3. Player visits `/dashboard` → redirected to `/explore`
4. Merchant visits `/explore` → redirected to `/dashboard`
5. Call `protectedProcedure` without auth → `UNAUTHORIZED` error
6. Close app during onboarding → re-login → resume at correct step
7. RLS migration applied → Prisma operations still work (service role bypass)

---

## File Manifest (33 files)

| # | File | Action |
|---|---|---|
| 1 | `package.json` | Modify (add deps) |
| 2 | `.env` | Modify (add service role key) |
| 3 | `src/lib/supabase.ts` | Create (server-only) |
| 4 | `src/lib/supabase-browser.ts` | Create (client-safe) |
| 5 | `src/trpc/init.ts` | Modify (real auth context + middleware) |
| 6 | `src/trpc/client.tsx` | Modify (ensure cookies sent) |
| 7 | `src/trpc/routers/_app.ts` | Modify (register onboarding router) |
| 8 | `src/app/auth/callback/route.ts` | Create |
| 9 | `middleware.ts` | Create |
| 10 | `src/schemas/onboarding.ts` | Create |
| 11 | `src/lib/services/auth.ts` | Create (server-only) |
| 12 | `src/use-cases/complete-onboarding.ts` | Create (server-only) |
| 13 | `src/trpc/routers/onboarding.ts` | Create |
| 14 | `src/hooks/use-auth.ts` | Create (client) |
| 15 | `src/app/(auth)/layout.tsx` | Create |
| 16 | `src/app/(auth)/login/page.tsx` | Create |
| 17 | `src/components/auth/login-form.tsx` | Create (client) |
| 18 | `src/app/(auth)/onboarding/role-select/page.tsx` | Create |
| 19 | `src/components/auth/role-select-form.tsx` | Create (client) |
| 20 | `src/app/(auth)/onboarding/player-profile/page.tsx` | Create |
| 21 | `src/components/auth/player-profile-form.tsx` | Create (client) |
| 22 | `src/app/(auth)/onboarding/merchant-profile/page.tsx` | Create |
| 23 | `src/components/auth/merchant-profile-form.tsx` | Create (client) |
| 24 | `src/app/(player)/layout.tsx` | Create |
| 25 | `src/app/(player)/explore/page.tsx` | Create (stub) |
| 26 | `src/app/(player)/sessions/page.tsx` | Create (stub) |
| 27 | `src/app/(player)/profile/page.tsx` | Create (stub) |
| 28 | `src/app/(merchant)/layout.tsx` | Create |
| 29 | `src/app/(merchant)/dashboard/page.tsx` | Create (stub) |
| 30 | `src/app/(merchant)/courts/page.tsx` | Create (stub) |
| 31 | `src/app/(merchant)/upsells/page.tsx` | Create (stub) |
| 32 | `src/app/page.tsx` | Modify (redirect logic) |
| 33 | `prisma/migrations/.../migration.sql` | Create (RLS policies) |
