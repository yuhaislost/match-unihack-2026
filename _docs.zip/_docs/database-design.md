# Database Design — Match MVP

## Overview

**24 tables** across **8 domains**, backed by PostgreSQL (Supabase) with Prisma ORM.

| Domain | Tables | Purpose |
|---|---|---|
| Users | `users`, `player_profiles`, `merchant_profiles` | Identity, roles, profiles |
| Venues | `venues`, `courts`, `court_availabilities`, `upsell_items` | Merchant inventory & scheduling |
| Sessions | `sessions`, `session_players`, `quick_match_queue_entries`, `match_requests`, `decline_cooldowns`, `venue_proposals`, `venue_proposal_votes` | Core matching & game lifecycle |
| Bookings | `bookings`, `booking_player_shares`, `booking_upsells`, `merchant_payouts` | Payments & financial records |
| Chat | `chat_rooms`, `chat_participants`, `chat_messages`, `message_read_receipts` | Messaging |
| Reviews | `venue_reviews`, `player_ratings` | Post-game feedback |
| Notifications | `notifications`, `notification_preferences` | Push notification tracking |
| System | `system_config` | Admin-tunable parameters |

**Schema file:** `prisma/schema.prisma`
**Migration:** `prisma/migrations/20260313164702_initial_data_model/migration.sql`
**Generated client:** `src/generated/prisma/` (gitignored)
**Prisma client singleton:** `src/lib/prisma.ts`

---

## Foundational Conventions

| Concern | Decision |
|---|---|
| **Primary keys** | UUID v4 via Postgres `gen_random_uuid()` on all tables |
| **Naming** | snake_case in Postgres (via `@map`), camelCase in application code |
| **Timestamps** | All tables have `created_at` (auto-set). Mutable tables also have `updated_at` (auto-managed by Prisma `@updatedAt`) |
| **Soft deletes** | `deleted_at` nullable timestamp on mutable domain tables (see below) |
| **Auth link** | `users.auth_user_id` FK to Supabase `auth.users` UUID — no standalone auth table |
| **Roles** | Single role per account: `PLAYER` XOR `MERCHANT` (enforced by enum, one profile per user) |
| **Spatial data** | `Decimal(10,7)` for lat/lng. Haversine via raw SQL; PostGIS can be added later |
| **Money** | `Decimal(10,2)` for all currency amounts. `Decimal(5,4)` for commission rates |

---

## Enums (18 total)

```
Role                  PLAYER | MERCHANT
SkillLevel            BEGINNER | INTERMEDIATE | ADVANCED
SessionMode           QUICK_MATCH | SCHEDULE_MATCH
GameType              SINGLES | DOUBLES
SessionStatus         SEARCHING | OPEN | CONFIRMING | MATCHED | BOOKED | IN_PROGRESS | COMPLETED | CANCELLED
SessionPlayerRole     CREATOR | MEMBER | BACKFILL
SessionPlayerStatus   PENDING | CONFIRMED | VENUE_CONFIRMED | DECLINED | LEFT | REMOVED
MatchRequestType      SYSTEM_AUTO | MANUAL_FEED | AUTOFILL_INVITE | SCHEDULE_JOIN
MatchRequestStatus    PENDING | ACCEPTED | DECLINED | TIMEOUT | CANCELLED | SUPERSEDED
AvailabilityType      RECURRING | ONE_OFF
VenueProposalStatus   PROPOSED | CONFIRMED | REJECTED
VenueProposalVoteType CONFIRM | REJECT
BookingStatus         PENDING | PAID | REFUNDED | PARTIALLY_REFUNDED | FAILED
PaymentShareStatus    PENDING | PAID | REFUNDED | FAILED
PayoutStatus          PENDING | COMPLETED | FAILED
ChatRoomType          SESSION_GROUP | DIRECT
NotificationType      MATCH_FOUND | JOIN_REQUEST | SESSION_FULL | SESSION_CANCELLED | VENUE_CONFIRMED | BOOKING_CONFIRMED | PAYMENT_RECEIVED | RATING_REMINDER | CHAT_MESSAGE
ConfigDataType        STRING | INT | FLOAT | BOOLEAN
```

---

## Table Details by Domain

### 1. Users & Profiles

#### `users`

Central identity table linked to Supabase Auth. Every account has exactly one role.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK, default `gen_random_uuid()` | |
| `auth_user_id` | UUID | UNIQUE, NOT NULL | FK to Supabase `auth.users` |
| `role` | `Role` | NOT NULL | PLAYER or MERCHANT |
| `email` | TEXT | NOT NULL | |
| `display_name` | TEXT | NOT NULL | |
| `avatar_url` | TEXT | nullable | Supabase Storage URL |
| `created_at` | TIMESTAMP | NOT NULL, default now | |
| `updated_at` | TIMESTAMP | NOT NULL, auto | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

**Relations:** Has one `PlayerProfile`, one `MerchantProfile`, one `NotificationPreference`. Referenced by most other tables.

#### `player_profiles`

Extended profile for PLAYER role users. Contains matchmaking preferences and denormalised stats.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `user_id` | UUID | UNIQUE, FK -> `users` | One profile per user |
| `skill_level` | `SkillLevel` | NOT NULL | Matching parameter |
| `latitude` | DECIMAL(10,7) | nullable | Last known location |
| `longitude` | DECIMAL(10,7) | nullable | |
| `search_radius_km` | INT | default 10 | Quick Match search radius |
| `bio` | TEXT | nullable | |
| `games_played` | INT | default 0 | Denormalised counter |
| `avg_sportsmanship_rating` | DECIMAL(3,2) | default 0 | Denormalised average |
| `total_ratings_received` | INT | default 0 | Denormalised counter |
| `availability_preferences` | JSONB | nullable | Recurring time windows |
| `quick_match_window_minutes` | INT | default 120 | Max future window |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |

#### `merchant_profiles`

Extended profile for MERCHANT role users. Tracks Stripe Connect onboarding state.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `user_id` | UUID | UNIQUE, FK -> `users` | One profile per user |
| `business_name` | TEXT | NOT NULL | |
| `stripe_connect_account_id` | TEXT | nullable | Set after Connect account creation |
| `stripe_charges_enabled` | BOOLEAN | default false | Updated via webhook |
| `stripe_onboarding_complete` | BOOLEAN | default false | Updated via webhook |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |

**Relations:** Owns many `venues`, receives many `merchant_payouts`.

---

### 2. Venues & Courts

#### `venues`

Physical badminton venues managed by merchants.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `merchant_id` | UUID | FK -> `merchant_profiles`, indexed | |
| `name` | TEXT | NOT NULL | |
| `description` | TEXT | nullable | |
| `address` | TEXT | NOT NULL | |
| `latitude` | DECIMAL(10,7) | NOT NULL | For proximity queries |
| `longitude` | DECIMAL(10,7) | NOT NULL | |
| `avg_rating` | DECIMAL(3,2) | default 0 | Denormalised from `venue_reviews` |
| `total_reviews` | INT | default 0 | Denormalised counter |
| `photo_urls` | TEXT[] | | Postgres array |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

#### `courts`

Individual bookable courts within a venue.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `venue_id` | UUID | FK -> `venues`, indexed | |
| `name` | TEXT | NOT NULL | e.g. "Court 1", "Court A" |
| `capacity` | INT | default 4 | Max players (2 for singles, 4 for doubles) |
| `hourly_rate` | DECIMAL(10,2) | NOT NULL | |
| `photo_urls` | TEXT[] | | |
| `is_active` | BOOLEAN | default true | Merchants can deactivate |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

#### `court_availabilities`

Defines when a court is bookable. Supports both recurring weekly schedules and one-off date overrides.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `court_id` | UUID | FK -> `courts` | |
| `type` | `AvailabilityType` | NOT NULL | RECURRING or ONE_OFF |
| `day_of_week` | INT | nullable | 0-6 (Sun-Sat), for RECURRING |
| `specific_date` | DATE | nullable | For ONE_OFF |
| `start_time` | TIME | NOT NULL | |
| `end_time` | TIME | NOT NULL | |
| `is_available` | BOOLEAN | default true | false = blocked/maintenance |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |

**Indexes:** `(court_id, day_of_week)`, `(court_id, specific_date)`

#### `upsell_items`

Additional items merchants offer (equipment rental, refreshments, services).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `venue_id` | UUID | FK -> `venues`, indexed | |
| `name` | TEXT | NOT NULL | |
| `description` | TEXT | nullable | |
| `price` | DECIMAL(10,2) | NOT NULL | |
| `photo_url` | TEXT | nullable | |
| `is_active` | BOOLEAN | default true | |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

---

### 3. Sessions & Matching

#### `sessions`

Central table for both Quick Match and Schedule Match game sessions. Tracks the full lifecycle through 8 status states.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `mode` | `SessionMode` | NOT NULL | QUICK_MATCH or SCHEDULE_MATCH |
| `game_type` | `GameType` | NOT NULL | SINGLES or DOUBLES |
| `status` | `SessionStatus` | default SEARCHING | 8-state lifecycle |
| `creator_id` | UUID | FK -> `users`, indexed | |
| `max_players` | INT | NOT NULL | 2 (singles) or 4 (doubles) |
| `current_player_count` | INT | default 1 | Denormalised |
| `preferred_skill_min` | `SkillLevel` | nullable | Filter preference |
| `preferred_skill_max` | `SkillLevel` | nullable | Filter preference |
| `auto_accept` | BOOLEAN | default false | Schedule Match: auto-accept joiners |
| `scheduled_start_time` | TIMESTAMP | nullable | Schedule Match only |
| `scheduled_end_time` | TIMESTAMP | nullable | |
| `actual_start_time` | TIMESTAMP | nullable | Set when IN_PROGRESS |
| `actual_end_time` | TIMESTAMP | nullable | Set when COMPLETED |
| `venue_id` | UUID | nullable, FK -> `venues` | Set after venue selection |
| `court_id` | UUID | nullable, FK -> `courts` | Set after venue selection |
| `venue_confirmed_at` | TIMESTAMP | nullable | |
| `venue_selection_deadline` | TIMESTAMP | nullable | Auto-cancel if missed |
| `cancel_reason` | TEXT | nullable | |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

**Index:** `(status, mode)` — powers feed queries and status-based lookups.

**Session Status Lifecycle:**
```
SEARCHING → CONFIRMING → MATCHED → BOOKED → IN_PROGRESS → COMPLETED
    ↓           ↓           ↓         ↓          ↓
 CANCELLED  CANCELLED   CANCELLED  CANCELLED  CANCELLED

OPEN (Schedule Match) → CONFIRMING → ... (same as above)
```

#### `session_players`

Join table linking users to sessions with role and status tracking.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `session_id` | UUID | FK -> `sessions` | |
| `player_id` | UUID | FK -> `users`, indexed | |
| `role` | `SessionPlayerRole` | NOT NULL | CREATOR, MEMBER, or BACKFILL |
| `status` | `SessionPlayerStatus` | default PENDING | |
| `is_pair_unit` | BOOLEAN | default false | Doubles: entered as a pair |
| `paired_with_player_id` | UUID | nullable, FK -> `users` | Partner in pair |
| `joined_at` | TIMESTAMP | default now | |
| `left_at` | TIMESTAMP | nullable | Set on departure |
| `created_at` | TIMESTAMP | NOT NULL | |

**Unique:** `(session_id, player_id)` — one entry per player per session.

#### `quick_match_queue_entries`

Real-time matching queue for Quick Match. Players enter with their location and preferences; the scoring algorithm scans active entries.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `player_id` | UUID | FK -> `users`, indexed | |
| `game_type` | `GameType` | NOT NULL | |
| `latitude` | DECIMAL(10,7) | NOT NULL | Queue-time location |
| `longitude` | DECIMAL(10,7) | NOT NULL | |
| `search_radius_km` | INT | NOT NULL | |
| `skill_level` | `SkillLevel` | NOT NULL | Snapshot from profile |
| `window_start` | TIMESTAMP | NOT NULL | Availability window |
| `window_end` | TIMESTAMP | NOT NULL | |
| `is_pair` | BOOLEAN | default false | Doubles: queued as a pair |
| `pair_session_id` | UUID | nullable, FK -> `sessions` | Partial doubles pair session |
| `is_active` | BOOLEAN | default true | Deactivated on match/cancel |
| `has_priority` | BOOLEAN | default false | Re-queued after failed match |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |

**Index:** `(is_active, game_type, latitude, longitude)` — composite for queue scanning.

Note: The unique constraint "one active entry per player" is enforced at the application level since Prisma does not support partial unique indexes. The service layer checks `is_active = true` before inserting.

#### `match_requests`

Tracks all match proposals between players, regardless of origin (system auto-match, manual feed tap, schedule join, autofill invite).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `session_id` | UUID | nullable, FK -> `sessions` | |
| `requester_id` | UUID | FK -> `users` | |
| `recipient_id` | UUID | FK -> `users` | |
| `type` | `MatchRequestType` | NOT NULL | Origin of the request |
| `status` | `MatchRequestStatus` | default PENDING | |
| `composite_score` | DECIMAL(10,4) | nullable | Scoring algorithm output |
| `expires_at` | TIMESTAMP | NOT NULL | Auto-timeout deadline |
| `responded_at` | TIMESTAMP | nullable | |
| `cancel_reason` | TEXT | nullable | |
| `created_at` | TIMESTAMP | NOT NULL | |

**Indexes:** `(recipient_id, status)` for pending request lookup, `(session_id)` for session-scoped queries.

#### `decline_cooldowns`

Prevents re-matching between players who recently declined each other.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `player_a_id` | UUID | FK -> `users` | |
| `player_b_id` | UUID | FK -> `users` | |
| `expires_at` | TIMESTAMP | NOT NULL | Cooldown expiry |
| `created_at` | TIMESTAMP | NOT NULL | |

**Index:** `(player_a_id, player_b_id, expires_at)` — efficient cooldown check.

#### `venue_proposals`

After players match, the system proposes nearby venues. Players vote on proposals.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `session_id` | UUID | FK -> `sessions`, indexed | |
| `venue_id` | UUID | FK -> `venues` | |
| `court_id` | UUID | FK -> `courts` | |
| `proposed_by_id` | UUID | FK -> `users` | System or player |
| `rank` | INT | nullable | System-assigned rank |
| `distance_to_midpoint` | DECIMAL(10,4) | nullable | km from player midpoint |
| `price` | DECIMAL(10,2) | nullable | Court price for slot |
| `status` | `VenueProposalStatus` | default PROPOSED | |
| `created_at` | TIMESTAMP | NOT NULL | |

#### `venue_proposal_votes`

Per-player vote on a venue proposal.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `proposal_id` | UUID | FK -> `venue_proposals` | |
| `player_id` | UUID | FK -> `users` | |
| `vote` | `VenueProposalVoteType` | NOT NULL | CONFIRM or REJECT |
| `created_at` | TIMESTAMP | NOT NULL | |

**Unique:** `(proposal_id, player_id)` — one vote per player per proposal.

---

### 4. Bookings & Payments

#### `bookings`

Created when a session's venue is confirmed. Tracks the aggregate financial breakdown and Stripe payment state.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `session_id` | UUID | UNIQUE, FK -> `sessions` | One booking per session |
| `venue_id` | UUID | FK -> `venues`, indexed | |
| `court_id` | UUID | FK -> `courts` | |
| `start_time` | TIMESTAMP | NOT NULL | |
| `end_time` | TIMESTAMP | NOT NULL | |
| `total_court_cost` | DECIMAL(10,2) | NOT NULL | Court hourly rate * duration |
| `total_upsell_cost` | DECIMAL(10,2) | NOT NULL | Sum of all upsells |
| `total_amount` | DECIMAL(10,2) | NOT NULL | Court + upsells |
| `commission_amount` | DECIMAL(10,2) | NOT NULL | Platform commission |
| `commission_rate` | DECIMAL(5,4) | NOT NULL | e.g. 0.1000 = 10% |
| `merchant_payout_amount` | DECIMAL(10,2) | NOT NULL | total - commission |
| `stripe_checkout_session_id` | TEXT | nullable | |
| `stripe_payment_intent_id` | TEXT | nullable | |
| `status` | `BookingStatus` | default PENDING | |
| `paid_at` | TIMESTAMP | nullable | Set on successful payment |
| `refunded_at` | TIMESTAMP | nullable | |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |

#### `booking_player_shares`

Per-player payment split for a booking. Court cost is split equally; upsells are individual.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `booking_id` | UUID | FK -> `bookings` | |
| `player_id` | UUID | FK -> `users` | |
| `court_share_amount` | DECIMAL(10,2) | NOT NULL | Equal split of court cost |
| `upsell_total` | DECIMAL(10,2) | NOT NULL | Player's individual upsells |
| `total_amount` | DECIMAL(10,2) | NOT NULL | court_share + upsells |
| `stripe_payment_intent_id` | TEXT | nullable | Per-player payment |
| `status` | `PaymentShareStatus` | default PENDING | |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |

**Unique:** `(booking_id, player_id)` — one share per player per booking.

#### `booking_upsells`

Individual upsell line items within a player's booking share. Stores **price snapshots** so merchant price changes don't alter historical records.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `booking_player_share_id` | UUID | FK -> `booking_player_shares`, indexed | |
| `upsell_item_id` | UUID | FK -> `upsell_items` | Reference to catalog item |
| `name` | TEXT | NOT NULL | **Snapshot** at booking time |
| `price` | DECIMAL(10,2) | NOT NULL | **Snapshot** at booking time |
| `quantity` | INT | default 1 | |
| `created_at` | TIMESTAMP | NOT NULL | |

#### `merchant_payouts`

Tracks Stripe Connect transfers to merchants after successful bookings.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `merchant_id` | UUID | FK -> `merchant_profiles`, indexed | |
| `booking_id` | UUID | UNIQUE, FK -> `bookings` | One payout per booking |
| `amount` | DECIMAL(10,2) | NOT NULL | |
| `stripe_transfer_id` | TEXT | nullable | |
| `stripe_payout_id` | TEXT | nullable | |
| `status` | `PayoutStatus` | default PENDING | |
| `completed_at` | TIMESTAMP | nullable | |
| `created_at` | TIMESTAMP | NOT NULL | |

---

### 5. Chat

#### `chat_rooms`

Container for conversations. Session group chats are auto-created when a session is matched. DMs are created on demand.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `type` | `ChatRoomType` | NOT NULL | SESSION_GROUP or DIRECT |
| `session_id` | UUID | nullable, UNIQUE, FK -> `sessions` | For group chats |
| `created_at` | TIMESTAMP | NOT NULL | |
| `retention_expires_at` | TIMESTAMP | nullable | session + 30 days |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

#### `chat_participants`

Membership in a chat room.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `chat_room_id` | UUID | FK -> `chat_rooms` | |
| `user_id` | UUID | FK -> `users` | |
| `joined_at` | TIMESTAMP | default now | |
| `left_at` | TIMESTAMP | nullable | |

**Unique:** `(chat_room_id, user_id)`

#### `chat_messages`

Individual messages. Delivered in real-time via Supabase Realtime, persisted here.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `chat_room_id` | UUID | FK -> `chat_rooms` | |
| `sender_id` | UUID | FK -> `users` | |
| `content` | TEXT | NOT NULL | |
| `created_at` | TIMESTAMP | NOT NULL | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

**Index:** `(chat_room_id, created_at)` — message history pagination.

#### `message_read_receipts`

Per-user read tracking for each message.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `message_id` | UUID | FK -> `chat_messages` | |
| `user_id` | UUID | FK -> `users` | |
| `read_at` | TIMESTAMP | default now | |

**Unique:** `(message_id, user_id)`

---

### 6. Reviews & Ratings

#### `venue_reviews`

Post-session venue reviews by players. Rating is 1-5.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `venue_id` | UUID | FK -> `venues`, indexed | |
| `player_id` | UUID | FK -> `users` | |
| `session_id` | UUID | FK -> `sessions` | Must have played at venue |
| `rating` | INT | NOT NULL | 1-5 (validated in app) |
| `review_text` | TEXT | nullable | |
| `is_reported` | BOOLEAN | default false | |
| `report_reason` | TEXT | nullable | |
| `created_at` | TIMESTAMP | NOT NULL | |
| `updated_at` | TIMESTAMP | NOT NULL | |
| `deleted_at` | TIMESTAMP | nullable | Soft delete |

**Unique:** `(player_id, session_id)` — one review per player per session.

#### `player_ratings`

Post-session sportsmanship ratings between players. Rating is 1-5.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `rated_player_id` | UUID | FK -> `users`, indexed | Player being rated |
| `rater_player_id` | UUID | FK -> `users` | Player giving the rating |
| `session_id` | UUID | FK -> `sessions` | Must have shared session |
| `sportsmanship_rating` | INT | NOT NULL | 1-5 (validated in app) |
| `created_at` | TIMESTAMP | NOT NULL | |

**Unique:** `(rater_player_id, rated_player_id, session_id)` — one rating per rater/ratee/session.

---

### 7. Notifications

#### `notifications`

Push notification records for the in-app notification feed.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `user_id` | UUID | FK -> `users` | |
| `type` | `NotificationType` | NOT NULL | Categorisation for filtering |
| `title` | TEXT | NOT NULL | |
| `body` | TEXT | NOT NULL | |
| `data` | JSONB | nullable | Arbitrary metadata payload |
| `is_read` | BOOLEAN | default false | |
| `read_at` | TIMESTAMP | nullable | |
| `created_at` | TIMESTAMP | NOT NULL | |

**Index:** `(user_id, is_read, created_at)` — notification feed with unread filtering.

#### `notification_preferences`

Per-user toggle for each notification category.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `user_id` | UUID | UNIQUE, FK -> `users` | One row per user |
| `match_found` | BOOLEAN | default true | |
| `session_updates` | BOOLEAN | default true | |
| `chat_messages` | BOOLEAN | default true | |
| `booking_confirmations` | BOOLEAN | default true | |
| `rating_reminders` | BOOLEAN | default true | |
| `updated_at` | TIMESTAMP | NOT NULL | |

---

### 8. System Configuration

#### `system_config`

Key-value store for admin-tunable parameters (e.g. scoring thresholds, timeout durations, commission rates).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | UUID | PK | |
| `key` | TEXT | UNIQUE | e.g. `auto_match_threshold` |
| `value` | TEXT | NOT NULL | Stored as string, cast by app |
| `description` | TEXT | nullable | Admin-facing description |
| `data_type` | `ConfigDataType` | NOT NULL | STRING, INT, FLOAT, BOOLEAN |
| `updated_at` | TIMESTAMP | NOT NULL | |

---

## Indexing Strategy

All indexes are defined in the Prisma schema and created in the migration SQL.

### Unique Indexes

| Table | Columns | Purpose |
|---|---|---|
| `users` | `auth_user_id` | One app user per Supabase auth identity |
| `player_profiles` | `user_id` | One player profile per user |
| `merchant_profiles` | `user_id` | One merchant profile per user |
| `session_players` | `(session_id, player_id)` | One entry per player per session |
| `venue_proposal_votes` | `(proposal_id, player_id)` | One vote per player per proposal |
| `bookings` | `session_id` | One booking per session |
| `booking_player_shares` | `(booking_id, player_id)` | One share per player per booking |
| `merchant_payouts` | `booking_id` | One payout per booking |
| `chat_rooms` | `session_id` | One group chat per session |
| `chat_participants` | `(chat_room_id, user_id)` | One membership per user per room |
| `message_read_receipts` | `(message_id, user_id)` | One receipt per user per message |
| `venue_reviews` | `(player_id, session_id)` | One review per player per session |
| `player_ratings` | `(rater_player_id, rated_player_id, session_id)` | One rating per rater/ratee/session |
| `notification_preferences` | `user_id` | One preference set per user |
| `system_config` | `key` | Unique config keys |

### Performance Indexes

| Table | Columns | Query Pattern |
|---|---|---|
| `venues` | `merchant_id` | Merchant's venue list |
| `courts` | `venue_id` | Venue's court list |
| `court_availabilities` | `(court_id, day_of_week)` | Recurring schedule lookup |
| `court_availabilities` | `(court_id, specific_date)` | Date-specific override lookup |
| `upsell_items` | `venue_id` | Venue's upsell catalog |
| `sessions` | `(status, mode)` | Feed queries, active session filtering |
| `sessions` | `creator_id` | User's created sessions |
| `session_players` | `player_id` | User's session history |
| `quick_match_queue_entries` | `(is_active, game_type, latitude, longitude)` | Queue scanning by the matching algorithm |
| `quick_match_queue_entries` | `player_id` | Player's queue status lookup |
| `match_requests` | `(recipient_id, status)` | Pending requests for a player |
| `match_requests` | `session_id` | Requests within a session |
| `decline_cooldowns` | `(player_a_id, player_b_id, expires_at)` | Cooldown existence check |
| `venue_proposals` | `session_id` | Proposals for a session |
| `bookings` | `venue_id` | Venue booking history |
| `booking_upsells` | `booking_player_share_id` | Upsells within a share |
| `merchant_payouts` | `merchant_id` | Merchant payout history |
| `chat_messages` | `(chat_room_id, created_at)` | Message pagination |
| `venue_reviews` | `venue_id` | Venue review aggregation |
| `player_ratings` | `rated_player_id` | Player rating aggregation |
| `notifications` | `(user_id, is_read, created_at)` | Notification feed |

### Future: Geospatial

Lat/lng are stored as `Decimal(10,7)`. For MVP, proximity queries use Haversine via raw SQL. If query performance degrades, add the PostGIS extension and a GIST index:

```sql
CREATE EXTENSION IF NOT EXISTS postgis;
ALTER TABLE venues ADD COLUMN location geography(Point, 4326);
CREATE INDEX idx_venues_location ON venues USING GIST(location);
```

---

## Soft Delete Strategy

**Soft-deleted tables** (have `deleted_at` column):
- `users`, `venues`, `courts`, `upsell_items`, `sessions`, `chat_rooms`, `chat_messages`, `venue_reviews`

**Hard-delete / append-only tables** (no `deleted_at`):
- `player_profiles`, `merchant_profiles`, `court_availabilities`, `session_players`, `quick_match_queue_entries`, `match_requests`, `decline_cooldowns`, `venue_proposals`, `venue_proposal_votes`, `bookings`, `booking_player_shares`, `booking_upsells`, `merchant_payouts`, `chat_participants`, `message_read_receipts`, `player_ratings`, `notifications`, `notification_preferences`, `system_config`

**Application-level enforcement:** All queries on soft-deletable tables must include `WHERE deleted_at IS NULL` unless explicitly querying archived records. This is enforced in the service layer, not via Prisma middleware.

---

## Denormalisation Strategy

Denormalised fields avoid expensive aggregation queries on hot read paths. They are updated by application code in the relevant service layer (not database triggers).

| Field | Source | Updated When |
|---|---|---|
| `player_profiles.games_played` | Count of COMPLETED sessions | After session completes |
| `player_profiles.avg_sportsmanship_rating` | Average of `player_ratings.sportsmanship_rating` | After `PlayerRating` insert |
| `player_profiles.total_ratings_received` | Count of `player_ratings` received | After `PlayerRating` insert |
| `venues.avg_rating` | Average of `venue_reviews.rating` | After `VenueReview` insert |
| `venues.total_reviews` | Count of `venue_reviews` | After `VenueReview` insert |
| `sessions.current_player_count` | Count of active `session_players` | After `SessionPlayer` insert/update |

---

## Foreign Key Behaviour

| Relationship Type | ON DELETE | Rationale |
|---|---|---|
| Required parent (e.g. `session_players.session_id`) | RESTRICT | Cannot delete a session with players |
| Optional parent (e.g. `sessions.venue_id`) | SET NULL | Venue can be unset |
| Profile -> User (e.g. `player_profiles.user_id`) | RESTRICT | Cannot delete user with profile |

All foreign keys use `ON UPDATE CASCADE` (Prisma default).

---

## Connection Configuration

| Setting | Value | Purpose |
|---|---|---|
| `DATABASE_URL` | Supabase pooler (port 6543, PgBouncer) | Application runtime queries |
| `DIRECT_URL` | Supabase direct (port 5432) | Migrations only (no PgBouncer) |

Configured in `prisma.config.ts`:
```ts
datasource: {
  url: process.env["DATABASE_URL"],
  directUrl: process.env["DIRECT_URL"],
}
```

The Prisma client singleton (`src/lib/prisma.ts`) uses the `@prisma/adapter-pg` PrismaPg adapter with the pooled `DATABASE_URL`.

---

## Prisma to Postgres Naming Map

Prisma uses camelCase in application code. All models and fields are mapped to snake_case in Postgres via `@map` and `@@map`.

| Prisma Model | Postgres Table |
|---|---|
| `User` | `users` |
| `PlayerProfile` | `player_profiles` |
| `MerchantProfile` | `merchant_profiles` |
| `Venue` | `venues` |
| `Court` | `courts` |
| `CourtAvailability` | `court_availabilities` |
| `UpsellItem` | `upsell_items` |
| `Session` | `sessions` |
| `SessionPlayer` | `session_players` |
| `QuickMatchQueueEntry` | `quick_match_queue_entries` |
| `MatchRequest` | `match_requests` |
| `DeclineCooldown` | `decline_cooldowns` |
| `VenueProposal` | `venue_proposals` |
| `VenueProposalVote` | `venue_proposal_votes` |
| `Booking` | `bookings` |
| `BookingPlayerShare` | `booking_player_shares` |
| `BookingUpsell` | `booking_upsells` |
| `MerchantPayout` | `merchant_payouts` |
| `ChatRoom` | `chat_rooms` |
| `ChatParticipant` | `chat_participants` |
| `ChatMessage` | `chat_messages` |
| `MessageReadReceipt` | `message_read_receipts` |
| `VenueReview` | `venue_reviews` |
| `PlayerRating` | `player_ratings` |
| `Notification` | `notifications` |
| `NotificationPreference` | `notification_preferences` |
| `SystemConfig` | `system_config` |
