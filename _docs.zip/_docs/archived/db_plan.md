 Data Model Design — Match MVP

 Context

 Match is a badminton-focused sports matching social network. We need a logical data model that supports:
 - Two user roles (Player / Merchant) linked to Supabase Auth
 - Quick Match (real-time queue + scoring algorithm) and Schedule Match (open lobby)
 - Unified session lifecycle with 8 states
 - Venue discovery, court management, and time-slot availability
 - Booking with Stripe payment splitting and merchant payouts
 - In-app chat (session group + DMs)
 - Ratings & reviews (player sportsmanship + venue reviews)
 - Merchant upsells (equipment, refreshments, services)
 - Admin-tunable system configuration
 - Soft deletes where applicable

 Design Decisions

 - Auth: Link to Supabase auth.users via UUID FK — no standalone User table
 - Roles: Single role per account (Player XOR Merchant)
 - Deletes: Soft delete (deleted_at timestamp) on mutable domain tables
 - Config: system_config key-value table for admin-tunable timing constants
 - IDs: UUIDs for all primary keys (Postgres gen_random_uuid())
 - Timestamps: All tables get created_at and updated_at
 - Spatial: Store lat/lng as Decimal columns (Prisma doesn't natively support PostGIS, but we can use raw SQL for Haversine/distance queries and add PostGIS
 extension later if needed)

 ---
 Entity-Relationship Diagram

 erDiagram
     %% ─── USERS & PROFILES ───
     User {
         uuid id PK
         uuid auth_user_id UK "FK → auth.users"
         enum role "PLAYER | MERCHANT"
         string email
         string display_name
         string avatar_url
         timestamp created_at
         timestamp updated_at
         timestamp deleted_at "nullable, soft delete"
     }

     PlayerProfile {
         uuid id PK
         uuid user_id FK "UK → User"
         enum skill_level "BEGINNER | INTERMEDIATE | ADVANCED"
         decimal latitude "nullable"
         decimal longitude "nullable"
         int search_radius_km "default 10"
         string bio "nullable"
         int games_played "default 0, denormalised"
         decimal avg_sportsmanship_rating "default 0, denormalised"
         int total_ratings_received "default 0, denormalised"
         json availability_preferences "nullable, recurring windows"
         int quick_match_window_minutes "default 120"
         timestamp created_at
         timestamp updated_at
     }

     MerchantProfile {
         uuid id PK
         uuid user_id FK "UK → User"
         string business_name
         string stripe_connect_account_id "nullable"
         boolean stripe_charges_enabled "default false"
         boolean stripe_onboarding_complete "default false"
         timestamp created_at
         timestamp updated_at
     }

     %% ─── VENUES & COURTS ───
     Venue {
         uuid id PK
         uuid merchant_id FK "→ MerchantProfile"
         string name
         string description "nullable"
         string address
         decimal latitude
         decimal longitude
         decimal avg_rating "default 0, denormalised"
         int total_reviews "default 0, denormalised"
         string[] photo_urls
         timestamp created_at
         timestamp updated_at
         timestamp deleted_at "nullable"
     }

     Court {
         uuid id PK
         uuid venue_id FK "→ Venue"
         string name "e.g. Court 1, Court A"
         int capacity "default 4"
         decimal hourly_rate
         string[] photo_urls
         boolean is_active "default true"
         timestamp created_at
         timestamp updated_at
         timestamp deleted_at "nullable"
     }

     CourtAvailability {
         uuid id PK
         uuid court_id FK "→ Court"
         enum type "RECURRING | ONE_OFF"
         int day_of_week "nullable, 0-6 for recurring"
         date specific_date "nullable, for one-off"
         time start_time
         time end_time
         boolean is_available "default true, false = blocked"
         timestamp created_at
         timestamp updated_at
     }

     UpsellItem {
         uuid id PK
         uuid venue_id FK "→ Venue"
         string name
         string description "nullable"
         decimal price
         string photo_url "nullable"
         boolean is_active "default true"
         timestamp created_at
         timestamp updated_at
         timestamp deleted_at "nullable"
     }

     %% ─── SESSIONS & MATCHING ───
     Session {
         uuid id PK
         enum mode "QUICK_MATCH | SCHEDULE_MATCH"
         enum game_type "SINGLES | DOUBLES"
         enum status "SEARCHING | OPEN | CONFIRMING | MATCHED | BOOKED | IN_PROGRESS | COMPLETED | CANCELLED"
         uuid creator_id FK "→ User"
         int max_players "2 or 4"
         int current_player_count "denormalised"
         enum preferred_skill_min "nullable"
         enum preferred_skill_max "nullable"
         boolean auto_accept "default false, schedule match"
         timestamp scheduled_start_time "nullable, schedule match"
         timestamp scheduled_end_time "nullable"
         timestamp actual_start_time "nullable"
         timestamp actual_end_time "nullable"
         uuid venue_id FK "nullable → Venue"
         uuid court_id FK "nullable → Court"
         timestamp venue_confirmed_at "nullable"
         timestamp venue_selection_deadline "nullable"
         string cancel_reason "nullable"
         timestamp created_at
         timestamp updated_at
         timestamp deleted_at "nullable"
     }

     SessionPlayer {
         uuid id PK
         uuid session_id FK "→ Session"
         uuid player_id FK "→ User"
         enum role "CREATOR | MEMBER | BACKFILL"
         enum status "PENDING | CONFIRMED | VENUE_CONFIRMED | DECLINED | LEFT | REMOVED"
         boolean is_pair_unit "default false, doubles partial group"
         uuid paired_with_player_id FK "nullable → User"
         timestamp joined_at
         timestamp left_at "nullable"
         timestamp created_at
     }

     QuickMatchQueueEntry {
         uuid id PK
         uuid player_id FK "UK → User"
         enum game_type "SINGLES | DOUBLES"
         decimal latitude
         decimal longitude
         int search_radius_km
         enum skill_level "player's skill"
         timestamp window_start
         timestamp window_end
         boolean is_pair "default false"
         uuid pair_session_id FK "nullable → Session, partial doubles pair"
         boolean is_active "default true"
         boolean has_priority "default false, re-queued players"
         timestamp created_at
         timestamp updated_at
     }

     MatchRequest {
         uuid id PK
         uuid session_id FK "nullable → Session"
         uuid requester_id FK "→ User"
         uuid recipient_id FK "→ User"
         enum type "SYSTEM_AUTO | MANUAL_FEED | AUTOFILL_INVITE | SCHEDULE_JOIN"
         enum status "PENDING | ACCEPTED | DECLINED | TIMEOUT | CANCELLED | SUPERSEDED"
         decimal composite_score "nullable"
         timestamp expires_at
         timestamp responded_at "nullable"
         string cancel_reason "nullable"
         timestamp created_at
     }

     DeclineCooldown {
         uuid id PK
         uuid player_a_id FK "→ User"
         uuid player_b_id FK "→ User"
         timestamp expires_at
         timestamp created_at
     }

     VenueProposal {
         uuid id PK
         uuid session_id FK "→ Session"
         uuid venue_id FK "→ Venue"
         uuid court_id FK "→ Court"
         uuid proposed_by_id FK "→ User"
         int rank "nullable, system rank"
         decimal distance_to_midpoint "nullable"
         decimal price "nullable"
         enum status "PROPOSED | CONFIRMED | REJECTED"
         timestamp created_at
     }

     VenueProposalVote {
         uuid id PK
         uuid proposal_id FK "→ VenueProposal"
         uuid player_id FK "→ User"
         enum vote "CONFIRM | REJECT"
         timestamp created_at
     }

     %% ─── BOOKINGS & PAYMENTS ───
     Booking {
         uuid id PK
         uuid session_id FK "UK → Session"
         uuid venue_id FK "→ Venue"
         uuid court_id FK "→ Court"
         timestamp start_time
         timestamp end_time
         decimal total_court_cost
         decimal total_upsell_cost
         decimal total_amount
         decimal commission_amount
         decimal commission_rate
         decimal merchant_payout_amount
         string stripe_checkout_session_id "nullable"
         string stripe_payment_intent_id "nullable"
         enum status "PENDING | PAID | REFUNDED | PARTIALLY_REFUNDED | FAILED"
         timestamp paid_at "nullable"
         timestamp refunded_at "nullable"
         timestamp created_at
         timestamp updated_at
     }

     BookingPlayerShare {
         uuid id PK
         uuid booking_id FK "→ Booking"
         uuid player_id FK "→ User"
         decimal court_share_amount
         decimal upsell_total "player's individual upsells"
         decimal total_amount
         string stripe_payment_intent_id "nullable"
         enum status "PENDING | PAID | REFUNDED | FAILED"
         timestamp created_at
         timestamp updated_at
     }

     BookingUpsell {
         uuid id PK
         uuid booking_player_share_id FK "→ BookingPlayerShare"
         uuid upsell_item_id FK "→ UpsellItem"
         string name "snapshot"
         decimal price "snapshot at booking time"
         int quantity "default 1"
         timestamp created_at
     }

     MerchantPayout {
         uuid id PK
         uuid merchant_id FK "→ MerchantProfile"
         uuid booking_id FK "→ Booking"
         decimal amount
         string stripe_transfer_id "nullable"
         string stripe_payout_id "nullable"
         enum status "PENDING | COMPLETED | FAILED"
         timestamp completed_at "nullable"
         timestamp created_at
     }

     %% ─── CHAT ───
     ChatRoom {
         uuid id PK
         enum type "SESSION_GROUP | DIRECT"
         uuid session_id FK "nullable → Session, for group chats"
         timestamp created_at
         timestamp retention_expires_at "nullable, session + 30 days"
         timestamp deleted_at "nullable"
     }

     ChatParticipant {
         uuid id PK
         uuid chat_room_id FK "→ ChatRoom"
         uuid user_id FK "→ User"
         timestamp joined_at
         timestamp left_at "nullable"
     }

     ChatMessage {
         uuid id PK
         uuid chat_room_id FK "→ ChatRoom"
         uuid sender_id FK "→ User"
         string content
         timestamp created_at
         timestamp read_at "nullable"
         timestamp deleted_at "nullable"
     }

     MessageReadReceipt {
         uuid id PK
         uuid message_id FK "→ ChatMessage"
         uuid user_id FK "→ User"
         timestamp read_at
     }

     %% ─── RATINGS & REVIEWS ───
     VenueReview {
         uuid id PK
         uuid venue_id FK "→ Venue"
         uuid player_id FK "→ User"
         uuid session_id FK "→ Session"
         int rating "1-5"
         string review_text "nullable"
         boolean is_reported "default false"
         string report_reason "nullable"
         timestamp created_at
         timestamp updated_at
         timestamp deleted_at "nullable"
     }

     PlayerRating {
         uuid id PK
         uuid rated_player_id FK "→ User"
         uuid rater_player_id FK "→ User"
         uuid session_id FK "→ Session"
         int sportsmanship_rating "1-5"
         timestamp created_at
     }

     %% ─── NOTIFICATIONS ───
     Notification {
         uuid id PK
         uuid user_id FK "→ User"
         enum type "MATCH_FOUND | JOIN_REQUEST | SESSION_FULL | etc"
         string title
         string body
         json data "nullable, metadata payload"
         boolean is_read "default false"
         timestamp read_at "nullable"
         timestamp created_at
     }

     NotificationPreference {
         uuid id PK
         uuid user_id FK "UK → User"
         boolean match_found "default true"
         boolean session_updates "default true"
         boolean chat_messages "default true"
         boolean booking_confirmations "default true"
         boolean rating_reminders "default true"
         timestamp updated_at
     }

     %% ─── SYSTEM CONFIG ───
     SystemConfig {
         uuid id PK
         string key UK "e.g. auto_match_threshold"
         string value
         string description "nullable"
         string data_type "STRING | INT | FLOAT | BOOLEAN"
         timestamp updated_at
     }

     %% ─── RELATIONSHIPS ───
     User ||--o| PlayerProfile : "has"
     User ||--o| MerchantProfile : "has"
     User ||--o| NotificationPreference : "has"

     MerchantProfile ||--o{ Venue : "owns"
     MerchantProfile ||--o{ MerchantPayout : "receives"

     Venue ||--o{ Court : "contains"
     Venue ||--o{ UpsellItem : "offers"
     Venue ||--o{ VenueReview : "receives"
     Venue ||--o{ VenueProposal : "proposed in"

     Court ||--o{ CourtAvailability : "has"

     User ||--o{ Session : "creates"
     Session ||--o{ SessionPlayer : "has"
     Session ||--o{ MatchRequest : "has"
     Session ||--o{ VenueProposal : "has"
     Session ||--o| Booking : "produces"
     Session ||--o| ChatRoom : "has"

     User ||--o{ QuickMatchQueueEntry : "enters"
     User ||--o{ MatchRequest : "sends"
     User ||--o{ MatchRequest : "receives"
     User ||--o{ DeclineCooldown : "has"

     VenueProposal ||--o{ VenueProposalVote : "has"

     Booking ||--o{ BookingPlayerShare : "split into"
     BookingPlayerShare ||--o{ BookingUpsell : "includes"
     Booking ||--o| MerchantPayout : "triggers"

     ChatRoom ||--o{ ChatParticipant : "has"
     ChatRoom ||--o{ ChatMessage : "contains"
     ChatMessage ||--o{ MessageReadReceipt : "tracked by"

     User ||--o{ VenueReview : "writes"
     User ||--o{ PlayerRating : "rates"
     User ||--o{ PlayerRating : "rated by"
     User ||--o{ Notification : "receives"
     User ||--o{ ChatParticipant : "participates"

 ---
 Table Summary by Domain

 ┌───────────────┬──────────────────────────────────────────────────────────────────────────────────────────────────────────────┬────────────────────────────────┐
 │    Domain     │                                                    Tables                                                    │            Purpose             │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Users         │ User, PlayerProfile, MerchantProfile                                                                         │ Identity, role, profiles       │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Venues        │ Venue, Court, CourtAvailability, UpsellItem                                                                  │ Merchant inventory &           │
 │               │                                                                                                              │ scheduling                     │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Sessions      │ Session, SessionPlayer, QuickMatchQueueEntry, MatchRequest, DeclineCooldown, VenueProposal,                  │ Core matching & game lifecycle │
 │               │ VenueProposalVote                                                                                            │                                │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Bookings      │ Booking, BookingPlayerShare, BookingUpsell, MerchantPayout                                                   │ Payments & financial records   │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Chat          │ ChatRoom, ChatParticipant, ChatMessage, MessageReadReceipt                                                   │ Messaging                      │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Reviews       │ VenueReview, PlayerRating                                                                                    │ Post-game feedback             │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ Notifications │ Notification, NotificationPreference                                                                         │ Push notification tracking     │
 ├───────────────┼──────────────────────────────────────────────────────────────────────────────────────────────────────────────┼────────────────────────────────┤
 │ System        │ SystemConfig                                                                                                 │ Admin-tunable parameters       │
 └───────────────┴──────────────────────────────────────────────────────────────────────────────────────────────────────────────┴────────────────────────────────┘

 Total: 24 tables

 ---
 Key Design Notes

 Denormalisation Strategy

 - PlayerProfile.games_played, avg_sportsmanship_rating, total_ratings_received — updated via triggers or application code after each PlayerRating insert
 - Venue.avg_rating, total_reviews — updated after each VenueReview insert
 - Session.current_player_count — updated on SessionPlayer changes
 - These avoid expensive aggregation queries on hot read paths

 Indexing Strategy (to add in Prisma schema)

 - User.auth_user_id — unique index (auth lookup)
 - QuickMatchQueueEntry(is_active, game_type, latitude, longitude) — composite for queue scanning
 - Session(status, mode) — composite for feed queries
 - MatchRequest(recipient_id, status) — pending request lookup
 - DeclineCooldown(player_a_id, player_b_id, expires_at) — cooldown check
 - CourtAvailability(court_id, day_of_week) and (court_id, specific_date) — availability lookup
 - ChatMessage(chat_room_id, created_at) — message history pagination
 - Notification(user_id, is_read, created_at) — notification feed
 - VenueReview(venue_id), PlayerRating(rated_player_id) — rating aggregation
 - Geospatial: Consider PostGIS GIST index on (latitude, longitude) for venue/player proximity queries

 Soft Delete

 Applied to: User, Venue, Court, UpsellItem, Session, ChatRoom, ChatMessage, VenueReview
 Not applied to: Transactional/append-only tables (MatchRequest, PlayerRating, Booking, Notification, SystemConfig)

 Unique Constraints

 - User.auth_user_id — one app user per auth identity
 - PlayerProfile.user_id — one player profile per user
 - MerchantProfile.user_id — one merchant profile per user
 - QuickMatchQueueEntry.player_id (where is_active = true) — one active queue entry per player
 - Booking.session_id — one booking per session
 - (VenueReview.player_id, VenueReview.session_id) — one venue review per player per session
 - (PlayerRating.rater_player_id, PlayerRating.rated_player_id, PlayerRating.session_id) — one rating per rater/rated/session combo
 - NotificationPreference.user_id — one preference set per user
 - SystemConfig.key — unique config keys

 Price Snapshots

 BookingUpsell stores name and price as snapshots at booking time, so merchant price changes don't retroactively alter historical booking records.

 ---
 Verification

 After implementing in prisma/schema.prisma:
 1. Run npx prisma validate to check schema syntax
 2. Run npx prisma migrate dev --name initial-data-model to generate and apply migration
 3. Run npx prisma generate to regenerate client types
 4. Verify generated SQL migration includes all indexes and constraints
 5. Spot-check FK relationships in Prisma Studio (npx prisma studio)