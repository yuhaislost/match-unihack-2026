We are creating a high-quality and functional MVP of a sports matching social network that connects similar players to venues. We have identified that local sport enthusiasts often spend immeasurable amounts of time scrolling through messy, often inactive and hard to deal with Facebook groups. Even if they manage to find a group that is within their local area, they are often too competitive or too casual. So…they start scrolling again, and again and again until either they run out of groups or have to get back to work from what otherwise was their freetime. Furthermore, once they do find a suitable group they may need to deal with logistic issues such as arranging a suitable time, payment processing for courts or even modes of transportation. Overall, this messy and unorganised exploration becomes a massive headache for sport-lovers that just want to hop into a pick-go whenever, and where ever. For beginners these spontaneous social groups may feel intimidating, and often they tend to shy away because they lack the confidence and fear to be judged. Their initial repulsion from these necessary social pick-up games may detour these younglings from the sport entirely or miss out on crucial experiences to immensely improve their skill. In an ever-evolving technological society where social interactions and healthy dopamine production are undermined by the ease of laying on the couch and hopping into a league of legends game. We see a different outcome. An outcome of technology to combat such a cancerous epidemic. We want to promote individuals of any sporting calibre about the beauty and magic of community through sport by streamlining away all the administrative overhead required to organise a game. We want Match, our app, to feel as smooth and convenient as possible.

As sincerely as we want to benefit players, we also want to bring value to merchants. Our platform of possibly millions of players provide an outlet for local businesses to thrive. Much like how Uber connects drivers with passengers, we also connect players with venues. Match aims to help merchants by streamlining their booking system directly into its fundamental matching system. We allow merchants of various sporting facilities to host their available courts on our platform for players to use and discover, which we hope to increase their revenue and conversion targets. Furthermore, to the benefit of both players and merchants Match also provides an upsell system where booking a particular venue may allow many merchants to add on additional items players may need. For example, recommendation of equipment rentals just when the players need it, or even end of game refreshments, maybe a permanent subscription. Fundamentally speaking, we wish to make commerce beneficial to everyone, because we believe value drives a thriving community of consumers and providers.

---

## MVP Scope

- **Sport:** Badminton (single sport focus — expand to others post-MVP)
- **Platform:** Mobile-first responsive web app (Next.js) — designed exclusively for mobile viewports, no desktop layouts
- **Revenue model:** Commission on venue bookings processed through Stripe

---

## User Roles

### Player
A person looking to find other players and book courts to play badminton. Players can create or join game sessions, chat with other players, rate venues and opponents, and pay for bookings.

### Merchant
A venue owner or manager who lists their badminton courts on Match. Merchants manage court availability, pricing, and upsell items. They receive payouts from bookings minus Match's commission.

---

## Features

### 1. Authentication

- Social login only (Google and Apple sign-in) — no email/password flows
- On first login, the user selects their role: **Player** or **Merchant**
- Players complete an onboarding profile (see below); merchants complete a venue setup flow

### 2. Player Onboarding & Profile

- **Display name** and **avatar** (pulled from social login, editable)
- **Skill level:** Self-reported — Beginner, Intermediate, or Advanced
- **Location:** GPS-based with a configurable search radius (e.g. 5km, 10km, 25km)
- **Availability preferences:** Optional recurring windows (e.g. "weekday evenings", "weekend mornings")
- **Bio:** Short free-text description
- **Stats (read-only):** Games played, average rating from other players, most visited venues

### 3. Player Matching & Game Sessions

> **Canonical reference:** `docs/matching-specification.md` — the matching spec is the source of truth for all matching behaviour. This section is a summary only.

This is the core feature of Match. The guiding principle is **get people playing above all else.** There are two matching modes:

#### 3a. Quick Match ("I want to play now")

- Player taps the **hero card** on the explore screen (Uber "Where to?" pattern) and selects Singles or Doubles. All other preferences come from profile defaults.
- Player enters the **Quick Match Queue** with their GPS location and a time window.
- **Dual-path matching:** matches can happen via (a) **system auto-match** when a candidate's composite score ≥ 0.65, or (b) **manual feed pick** where the player taps a suggestion card in the bottom sheet feed.
- System auto-match requires **mutual confirmation** (both accept within 2 min). Manual requests are **one-directional** (recipient accepts/declines within 2 min).
- If a system match fires while a manual request is pending, the **system match takes priority** and the manual request is cancelled.
- After all player slots are filled, the **venue selection phase** begins: top 3 venues ranked by geographic midpoint proximity, availability, and price. All players must confirm a venue within 15 minutes or the session is cancelled and players return to the queue.
- **Doubles** supports partial group formation — a confirmed pair stays in the queue as a unit while searching for 2 more players.

#### 3b. Schedule Match ("I want to plan a game for later")

- Player creates a session with date/time, game type (Singles/Doubles), preferred skill range, optional venue, and an auto-accept toggle.
- The session appears in the **bottom sheet feed** for nearby matching players as an open lobby.
- Players request to join; the creator approves (or auto-accept handles it).
- **Auto-fill safety net:** 1 hour before start time, if the session is ≥ 50% full but not complete, the system invites candidates sequentially (one at a time, 10-min response window each) from the broader player pool.

#### Match Scoring Algorithm

Every candidate is scored on four weighted factors:

| Factor | Weight |
|---|---|
| Availability overlap | 40% |
| Geographic distance | 30% |
| Sportsmanship rating | 20% |
| Skill level proximity | 10% |

Skill is intentionally the lowest weight — on a growing platform, getting a game happening matters more than perfect balance. Skill mismatch is clearly labelled in the UI so players can make informed decisions.

#### Explore Screen & Hero Card

The explore screen is the app's home view:

- **Full-screen Mapbox map** showing nearby venues (pins) and active Quick Match players (dots).
- **Pull-up bottom sheet** with a mixed feed of venues and open sessions, augmented with player suggestion cards during Quick Match searching.
- **Hero card overlay** (always visible, never scrolls) that transitions through 6 colour-coded states: Idle (blue) → Configure (blue) → Searching (pulsing blue) → Pending request (pulsing blue) → Confirmed (green) → Venue selection (amber).
- The feed **never locks** — players can browse venues and sessions while Quick Match runs in the background.

#### Unified Session Lifecycle

Both modes share the same lifecycle states:

1. **Searching** — player is in the Quick Match Queue (Quick Match only)
2. **Open** — session visible in feed, accepting join requests (Schedule Match only)
3. **Confirming** — mutual confirmation or manual request in progress (Quick Match only)
4. **Matched** — all slots filled, awaiting venue confirmation
5. **Booked** — venue confirmed, payment processed, awaiting game time
6. **In Progress** — game is happening
7. **Completed** — game finished, rating/review prompts shown
8. **Cancelled** — timeout, player cancellation, or insufficient players

#### Key Edge Cases

- **Decline cooldown:** Declined players are hidden from each other's feed for 10 minutes.
- **Player drops pre-booking:** Remaining players return to the queue with priority placement.
- **Player drops post-booking:** Session enters "Open (Backfill)" state; auto-fill seeks a replacement.
- **App backgrounded:** Queue entry persists for 5 minutes; push notifications still fire for matches.
- **Venue disagreement:** Players can propose alternatives within the 15-minute window; if no consensus, session is cancelled.

### 4. Venue Discovery & Booking

- Players can **browse nearby venues** on a map or list view, filtered by distance, price, and availability
- Each venue has a profile page showing:
  - Name, photos, address, and description
  - Available courts with time slots and pricing
  - Ratings and reviews from other players
  - Available upsell items
- **Booking flow:**
  1. Player selects a court and time slot (or this is tied to an existing session)
  2. Upsell items are presented (see section 7)
  3. Payment is processed via Stripe (see section 6)
  4. Confirmation is sent to all players in the session and the merchant
- Venues can also be **attached to a session** — a session creator picks a venue during or after session creation

### 5. In-App Chat

- **Session group chat:** Automatically created when a session is formed — all players in the session can message
- **Direct messages:** Players can DM each other (e.g. to coordinate before joining a session)
- Real-time messaging (WebSocket-based)
- Basic features: text messages, read receipts, typing indicators
- Chat history is retained for the life of the session + 30 days after completion

### 6. Payments (Stripe)

- **In-app checkout:** Players pay for venue bookings directly within Match
- **Cost splitting:** The total booking cost (court + upsells) is automatically split evenly among all players in the session
- **Commission:** Match deducts its commission from each booking before paying out to the merchant
- **Stripe Connect:** Merchants onboard via Stripe Connect for payouts
- **Refund policy:** If a session is cancelled before a configurable cutoff time, players are refunded automatically

### 7. Merchant Upsells

- Merchants can create **add-on items** attached to their venue:
  - Equipment rentals (e.g. racquet, shuttlecocks)
  - Refreshments (e.g. drinks, snacks)
  - Other services (e.g. coaching, towel service)
- Each upsell has a name, description, price, and optional photo
- Upsells are presented to players during the booking checkout flow
- Players can individually select which upsells they want (upsells are per-player, not split)

### 8. Ratings & Reviews

- After a session is marked **Completed**, all players are prompted to:
  - **Rate the venue** (1–5 stars + optional text review)
  - **Rate each other player** (1–5 stars for sportsmanship — no public text, just the score)
- Player ratings are averaged and displayed on their profile
- Venue ratings are averaged and displayed on the venue page
- Reviews can be reported for inappropriate content

### 9. Merchant Dashboard

- **Court management:** Add, edit, and remove courts; set capacity, pricing, and photos
- **Availability management:** Set recurring and one-off availability windows per court
- **Upsell management:** Create, edit, and remove upsell items
- **Booking overview:** View upcoming, in-progress, and past bookings with player details
- **Revenue analytics:** Total revenue, commission paid, bookings over time
- **Payout history:** View Stripe payout records

### 10. Notifications

- **Push notifications** (via web push / service worker):
  - Session invite or join request
  - Session full / session cancelled
  - Spontaneous match found
  - Booking confirmed
  - New chat message
  - Post-game rating reminder
- Players can configure notification preferences in settings

---

## Technical Stack

| Concern | Technology |
|---|---|
| Framework | Next.js 16.1.6 |
| API Layer | tRPC 11 with TanStack React Query |
| Database | Supabase (Postgres) with Prisma ORM |
| Authentication | Supabase Auth (Google & Apple social login) |
| Real-time | Supabase Realtime (WebSocket — chat, live session updates) |
| File Storage | Supabase Storage (avatars, venue photos, upsell images) |
| UI | Tailwind CSS 4 with shadcn/ui (Radix Primitives) |
| Validation | Zod (shared schemas between client and server) |
| Forms | React Hook Form with @hookform/resolvers |
| Maps & Geolocation | Mapbox GL JS (venue map, GPS-based player/venue proximity) |
| Date/Time | date-fns |
| Payments | Stripe (Checkout, Connect for merchant payouts, webhooks) |
| Push Notifications | Web Push API via service workers (`web-push`) |
| AI Provider | OpenAI Agent SDK (TypeScript) |
| Code Quality | Biome |

---

## Non-Functional Requirements

- **Mobile-only design:** All UI is designed for mobile viewports (max ~430px). No desktop or tablet layouts.
- **Performance:** Pages should load within 2 seconds on a 4G connection
- **Security:** All API routes authenticated; Stripe webhooks verified; no sensitive data in client state
- **Privacy:** Location data is used only for matching and never shared with other players (only approximate distance shown)
- **Accessibility:** Basic WCAG 2.1 AA compliance (contrast, font sizing, tap targets)

---

## Out of Scope (Post-MVP)

- Additional sports beyond badminton
- ELO/algorithmic skill rating
- Tournament or league management
- Desktop/tablet-optimized layouts
- Native mobile apps (React Native / Flutter)
- Advanced analytics for players (heatmaps, win/loss trends)
- Social features beyond chat (friend lists, activity feeds)
- Multi-language / i18n support
- Transportation coordination between players