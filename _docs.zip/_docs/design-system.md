# Match — Design System

## Design Philosophy

**Foundation:** Sophisticated, dark, minimalist — a premium feel that signals quality and trust. Clean surfaces, generous whitespace, restrained colour use. Think Uber/Linear dark mode.

**Fun layer:** Strategic bursts of personality through Ace (the mascot), colour-coded state transitions, micro-animations, and warm accent colours derived from Ace's palette. These moments "wow" without undermining the premium foundation.

**Principle:** The base UI should feel like a serious, well-crafted tool. The fun appears at emotional peaks — finding a match, confirming a game, celebrating a booking.

---

## Colour Palette

### Core Neutrals (Dark Theme)

The app is **dark-mode only** for MVP. The neutral scale forms the canvas — everything else is an accent.

| Token | Hex | Usage |
|---|---|---|
| `--background` | `#0C0C0E` | App background, deepest layer |
| `--surface-1` | `#141416` | Primary card surface (bottom sheet, feed cards) |
| `--surface-2` | `#1C1C20` | Elevated cards (hero card, modals, overlays) |
| `--surface-3` | `#24242A` | Interactive hover states, input fields |
| `--border` | `#2A2A32` | Default card borders, dividers |
| `--border-subtle` | `#1E1E24` | Subtle separation (e.g. between feed items) |

### Text

| Token | Hex | Usage |
|---|---|---|
| `--text-primary` | `#F5F5F7` | Headings, primary body text |
| `--text-secondary` | `#8E8E93` | Subtitles, metadata, helper text |
| `--text-tertiary` | `#636366` | Disabled text, timestamps, placeholders |
| `--text-inverse` | `#0C0C0E` | Text on bright-coloured backgrounds |

### Primary — Electric Blue

The hero card's signature colour. Represents active states, primary actions, and the Quick Match flow.

| Token | Hex | Usage |
|---|---|---|
| `--primary` | `#3B82F6` | Primary buttons, active hero card border, links |
| `--primary-hover` | `#2563EB` | Button hover, pressed state |
| `--primary-subtle` | `#1E3A5F` | Subtle blue backgrounds (selected toggle, badges) |
| `--primary-glow` | `rgba(59, 130, 246, 0.25)` | Pulsing border glow during Searching state |

### Success — Match Green

The "Match found!" celebration colour. Used sparingly for confirmed/positive states.

| Token | Hex | Usage |
|---|---|---|
| `--success` | `#22C55E` | Confirmed hero card border, success badges |
| `--success-hover` | `#16A34A` | Accept button hover |
| `--success-subtle` | `#14532D` | "Great match" badge background |
| `--success-glow` | `rgba(34, 197, 94, 0.25)` | Confirmed state glow |

### Warning — Venue Amber

Venue selection phase. Creates urgency without alarm.

| Token | Hex | Usage |
|---|---|---|
| `--warning` | `#F59E0B` | Venue selection hero card border, countdown |
| `--warning-hover` | `#D97706` | Confirm button hover |
| `--warning-subtle` | `#451A03` | "Best match" venue badge background |
| `--warning-glow` | `rgba(245, 158, 11, 0.25)` | Venue selection glow |

### Danger — Decline Red

Cancellations, errors, destructive actions. Used very sparingly.

| Token | Hex | Usage |
|---|---|---|
| `--danger` | `#EF4444` | Decline buttons, error states, cancel actions |
| `--danger-hover` | `#DC2626` | Decline hover |
| `--danger-subtle` | `#450A0A` | Error message backgrounds |

### Ace Accents — The "Fun" Palette

Derived directly from the Ace mascot SVG. These add personality at key emotional moments.

| Token | Hex | Source | Usage |
|---|---|---|---|
| `--ace-cyan` | `#00D2FF` | Ace's headband | Secondary accent — skill badges, player dots on map, onboarding highlights |
| `--ace-gold` | `#F6E05E` | Ace's medal | Ratings stars, achievement badges, premium highlights |
| `--ace-gold-deep` | `#D69E2E` | Ace's medal inner | Star fill, gold accents |
| `--ace-blush` | `#FFB6C1` | Ace's rosy cheeks | Sportsmanship rating highlight, social warmth moments |
| `--ace-warm` | `#E6B98A` | Ace's body | Avatar ring fallback, warm empty-state illustrations |
| `--ace-cream` | `#F9E4C8` | Ace's belly | Soft highlight on cards during celebration states |

### Usage Guidelines

- **90% of the UI** uses only neutrals + primary blue. The dark canvas with blue accents creates the sophisticated base.
- **Success green** appears only during match confirmation and post-booking.
- **Warning amber** appears only during venue selection.
- **Ace colours** appear in: player avatars/badges, ratings, empty states with Ace illustrations, onboarding, and micro-celebration animations.
- **Never combine** more than 2 accent colours on the same card/component.

---

## Typography

### Font Stack

| Token | Font | Fallback | Usage |
|---|---|---|---|
| `--font-sans` | Geist Sans | system-ui, sans-serif | All UI text |
| `--font-mono` | Geist Mono | monospace | Countdown timers, stats, match scores, session IDs |

### Type Scale

Mobile-first scale. All sizes in `rem` relative to 16px base.

| Name | Size | Weight | Line Height | Letter Spacing | Usage |
|---|---|---|---|---|---|
| `display` | 1.75rem (28px) | 700 | 1.15 | -0.02em | Splash/onboarding hero text only |
| `title-lg` | 1.375rem (22px) | 700 | 1.25 | -0.015em | Page titles ("Explore", "Sessions") |
| `title` | 1.125rem (18px) | 600 | 1.3 | -0.01em | Card titles ("Quick match", "Match found!") |
| `body` | 0.9375rem (15px) | 400 | 1.5 | 0 | Default body text, descriptions |
| `body-medium` | 0.9375rem (15px) | 500 | 1.5 | 0 | Emphasized body (venue names, player names) |
| `small` | 0.8125rem (13px) | 400 | 1.4 | 0.01em | Metadata, timestamps, helper text |
| `small-medium` | 0.8125rem (13px) | 500 | 1.4 | 0.01em | Badges, tags, tab labels |
| `caption` | 0.6875rem (11px) | 500 | 1.35 | 0.02em | Micro labels, countdown timers, map annotations |
| `mono` | 0.875rem (14px) | 500 (mono) | 1.4 | 0.05em | Timer countdowns ("1:48"), distances ("2.1km"), stats |

### Typography Rules

- **Headings** use negative letter-spacing for a tight, modern feel.
- **Body text** uses neutral letter-spacing for readability.
- **Small/caption** use positive letter-spacing for legibility at small sizes.
- **Numbers** in data contexts (countdowns, distances, ratings) always use `font-mono` for tabular alignment.
- **Max line length:** ~45 characters on mobile. The 430px viewport naturally constrains this.

---

## Spacing & Layout

### Spacing Scale

Based on a 4px grid. The scale uses `rem` for accessibility.

| Token | Value | Usage |
|---|---|---|
| `--space-1` | 0.25rem (4px) | Tight gaps (icon-to-text inline) |
| `--space-2` | 0.5rem (8px) | Small gaps (between badge items, compact padding) |
| `--space-3` | 0.75rem (12px) | Default inner padding for small elements |
| `--space-4` | 1rem (16px) | Standard padding (card inner, section gaps) |
| `--space-5` | 1.25rem (20px) | Card padding, comfortable gaps |
| `--space-6` | 1.5rem (24px) | Section separation, large card padding |
| `--space-8` | 2rem (32px) | Major section breaks |
| `--space-10` | 2.5rem (40px) | Page-level top/bottom padding |
| `--space-12` | 3rem (48px) | Hero card height spacer |

### Layout Constants

| Token | Value | Usage |
|---|---|---|
| `--viewport-max` | 430px | Max app width |
| `--safe-area-top` | env(safe-area-inset-top) | iOS notch |
| `--safe-area-bottom` | env(safe-area-inset-bottom) | iOS home indicator |
| `--nav-height` | 3.5rem (56px) | Bottom navigation bar |
| `--hero-card-min-height` | 4.5rem (72px) | Hero card collapsed |
| `--bottom-sheet-handle` | 1.5rem (24px) | Sheet drag handle area |

---

## Border Radius

Rounded corners are a key part of the friendly-but-premium feel.

| Token | Value | Usage |
|---|---|---|
| `--radius-sm` | 0.5rem (8px) | Badges, small tags, toggles |
| `--radius-md` | 0.75rem (12px) | Buttons, input fields, small cards |
| `--radius-lg` | 1rem (16px) | Primary cards (feed cards, hero card) |
| `--radius-xl` | 1.25rem (20px) | Bottom sheet, modal containers |
| `--radius-full` | 9999px | Avatars, pills, circular buttons |

---

## Shadows & Elevation

Subtle shadows on dark backgrounds — rely more on surface colour layering than drop shadows.

| Token | Value | Usage |
|---|---|---|
| `--shadow-sm` | `0 1px 2px rgba(0,0,0,0.3)` | Subtle lift (badges, small elements) |
| `--shadow-md` | `0 4px 12px rgba(0,0,0,0.4)` | Cards, hero card |
| `--shadow-lg` | `0 8px 24px rgba(0,0,0,0.5)` | Bottom sheet, modals |
| `--shadow-glow-blue` | `0 0 20px var(--primary-glow)` | Pulsing hero card (searching) |
| `--shadow-glow-green` | `0 0 20px var(--success-glow)` | Hero card (match confirmed) |
| `--shadow-glow-amber` | `0 0 20px var(--warning-glow)` | Hero card (venue selection) |

**Elevation model:**
```
Layer 0: --background        (app bg)
Layer 1: --surface-1         (feed cards, bottom sheet bg)
Layer 2: --surface-2         (hero card, modal, overlay)
Layer 3: --surface-3 + shadow-md  (pressed/focused interactive elements)
```

---

## Iconography

- **Icon set:** Lucide React (pairs with shadcn/ui)
- **Sizes:** 16px (inline), 20px (default), 24px (prominent/nav), 32px (hero card icons)
- **Stroke width:** 1.75px (slightly thinner than default for elegance)
- **Colour:** Inherits text colour by default. Uses accent colours only for state-specific icons (lightning bolt = blue, checkmark = green, map pin = amber).

---

## Component Tokens

### Buttons

| Variant | Background | Text | Border | Hover |
|---|---|---|---|---|
| **Primary** | `--primary` | `--text-inverse` | none | `--primary-hover` |
| **Secondary** | transparent | `--text-primary` | `--border` | `--surface-3` |
| **Ghost** | transparent | `--text-secondary` | none | `--surface-2` |
| **Danger** | `--danger` | `--text-inverse` | none | `--danger-hover` |
| **Success** | `--success` | `--text-inverse` | none | `--success-hover` |

**Button sizing:**

| Size | Height | Padding X | Font | Radius |
|---|---|---|---|---|
| `sm` | 2rem (32px) | 0.75rem | `small-medium` | `--radius-md` |
| `md` | 2.5rem (40px) | 1rem | `body-medium` | `--radius-md` |
| `lg` | 2.75rem (44px) | 1.25rem | `body-medium` | `--radius-md` |

**Tap target minimum:** 44px × 44px (WCAG 2.1 AA). Smaller visual buttons use invisible padding to meet this.

### Cards

| Variant | Background | Border | Radius | Padding |
|---|---|---|---|---|
| **Feed card** | `--surface-1` | `--border-subtle` | `--radius-lg` | `--space-4` |
| **Hero card** | `--surface-2` | 2px solid (colour varies by state) | `--radius-lg` | `--space-5` |
| **Venue card** | `--surface-1` | `--border-subtle` | `--radius-lg` | `--space-4` |
| **Player suggestion** | `--surface-1` | `--border-subtle` | `--radius-lg` | `--space-4` |

### Hero Card State Borders

| State | Border Colour | Animation |
|---|---|---|
| Idle | `--primary` (static) | None |
| Configure | `--primary` (static) | Card expand transition (200ms ease-out) |
| Searching | `--primary` | Pulsing glow: `shadow-glow-blue` fades in/out over 2s infinite |
| Pending request | `--primary` | Same pulsing glow as searching |
| Confirmed | `--success` (static) | Brief scale-up (1.02x) + glow flash on transition |
| Venue selection | `--warning` (static) | None |

### Input Fields

| State | Background | Border | Text |
|---|---|---|---|
| Default | `--surface-3` | `--border` | `--text-primary` |
| Focused | `--surface-3` | `--primary` | `--text-primary` |
| Error | `--surface-3` | `--danger` | `--text-primary` |
| Disabled | `--surface-1` | `--border-subtle` | `--text-tertiary` |

### Badges / Tags

| Variant | Background | Text | Usage |
|---|---|---|---|
| **Skill — Great match** | `--success-subtle` | `--success` | Skill compatibility badge |
| **Skill — Mismatch** | `--warning-subtle` | `--warning` | Skill gap badge |
| **Best match** | `--warning-subtle` | `--warning` | Top venue recommendation |
| **Player count** | `--primary-subtle` | `--primary` | "3 players nearby" |
| **Skill level** | `--surface-3` | `--text-secondary` | Beginner/Intermediate/Advanced |

---

## Animation & Motion

### Principles

- **Fast and responsive:** UI transitions complete in ≤200ms. Users should never wait for animations.
- **Fun at the right moments:** Celebratory animations (match found, booking confirmed) can be 400–600ms and more expressive.
- **No gratuitous motion:** If an animation doesn't communicate state change or provide feedback, remove it.
- **Respect user preferences:** Honour `prefers-reduced-motion`. All glow/pulse animations are disabled; transitions become instant.

### Timing Functions

| Token | Value | Usage |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` | Most transitions (cards, sheets, buttons) |
| `--ease-in-out` | `cubic-bezier(0.45, 0, 0.55, 1)` | Pulsing glow, looping animations |
| `--ease-spring` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Celebratory bounces (match confirmed scale-up) |

### Standard Durations

| Token | Value | Usage |
|---|---|---|
| `--duration-instant` | 100ms | Colour changes, opacity toggles |
| `--duration-fast` | 150ms | Button press, hover feedback |
| `--duration-normal` | 200ms | Card transitions, sheet open/close |
| `--duration-slow` | 400ms | Hero card state transitions |
| `--duration-celebration` | 600ms | Match found scale + glow flash |

### Key Animations

| Animation | Description | Duration | Easing |
|---|---|---|---|
| **Hero pulse** | Box-shadow glow fades between 0 and full opacity | 2s infinite | `--ease-in-out` |
| **Card expand** | Hero card height grows to accommodate configuration UI | 200ms | `--ease-out` |
| **Match celebrate** | Brief scale to 1.02x, green glow flash, then settle | 600ms | `--ease-spring` |
| **Feed card enter** | Slide up 8px + fade in as cards appear in the feed | 200ms | `--ease-out` |
| **Feed card exit** | Fade out + scale to 0.95x when a player is matched | 150ms | `--ease-out` |
| **Bottom sheet drag** | Follows finger with 1:1 tracking, snaps to positions | — | spring physics |
| **Countdown tick** | Mono digits animate with a subtle vertical slide on change | 100ms | `--ease-out` |
| **Dot bounce** | Animated loading dots (searching state) bounce sequentially | 1.4s infinite | `--ease-in-out` |

---

## Map Styling

The Mapbox map uses a **custom dark style** that complements the app's colour palette:

- **Base:** Dark grey landmass, near-black water
- **Roads:** Subtle `--border` colour, major roads slightly lighter
- **Labels:** `--text-tertiary` with `--font-sans`
- **Venue pins:** `--primary` fill with white icon, 32px circular
- **Player dots:** `--ace-cyan` fill, 12px circular with subtle pulse animation
- **Active player (self):** `--primary` fill, 16px with persistent pulse ring

---

## Ace Integration Points

The mascot Ace appears at emotional and instructional moments — never as decoration.

| Context | Ace Appearance | Purpose |
|---|---|---|
| **Empty queue** | Ace waving, looking around | "No players nearby yet" — softens disappointment |
| **Onboarding** | Ace with headband, welcoming | Guides the player through profile setup |
| **Match confirmed celebration** | Ace jumping/cheering (animated) | 600ms celebration moment — the emotional peak |
| **Post-game rating** | Ace holding star | Encourages the player to rate |
| **Error states** | Ace looking confused/sad | Humanises error messages |
| **Loading states** | Ace with bouncing shuttlecock | Makes waiting feel playful |

**Ace colours in the UI:**
- `--ace-cyan` is used for player presence dots on the map (ties back to Ace's headband)
- `--ace-gold` is used for rating stars (ties back to Ace's medal)
- `--ace-blush` appears subtly as the glow behind sportsmanship ratings

---

## Accessibility

- **Contrast ratios:** All text meets WCAG 2.1 AA (4.5:1 for body, 3:1 for large text). Verified:
  - `--text-primary` (#F5F5F7) on `--surface-1` (#141416) = 15.8:1
  - `--text-secondary` (#8E8E93) on `--surface-1` (#141416) = 5.2:1
  - `--text-inverse` (#0C0C0E) on `--primary` (#3B82F6) = 4.8:1
- **Tap targets:** Minimum 44×44px
- **Reduced motion:** `@media (prefers-reduced-motion: reduce)` disables all glow, pulse, and bounce animations
- **Focus indicators:** 2px `--primary` outline offset 2px on all interactive elements (keyboard/screen reader)

---

## Dark Theme Implementation Note

The app ships **dark mode only** for MVP. There is no light mode toggle. The CSS uses a flat dark theme (not `prefers-color-scheme` media query). This simplifies development and is consistent with the premium, immersive feel of the app. A light mode can be added post-MVP if needed.
