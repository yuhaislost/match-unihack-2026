# Match — Matching Feature Specification

---

## 1. Overview & Design Philosophy

The matching system is the core engine of Match. Its purpose is to minimise the time between a player wanting to play and actually being on a court. Every design decision below is guided by a single principle: **get people playing above all else.**

The system supports two distinct matching modes, each serving a different player intent:

|  | Quick Match | Schedule Match |
|---|---|---|
| **Intent** | "I want to play right now" | "I want to plan a game for later" |
| **Discovery** | System-driven auto-matching with manual feed override | Player-driven: open lobby visible in session feed |
| **Venue timing** | After match — players matched first, venue selected second | During or after — creator attaches venue at any point |
| **Fill method** | Instant auto-match when threshold met + manual feed picks | Open lobby + auto-fill safety net near start time |
| **Confirmation** | System path: mutual (both accept within 2 min). Manual path: one-directional request (recipient accepts/declines) | Join request: creator approves (or auto-accept toggle) |

---

## 2. Explore Screen & Hero Card Interaction

### 2.1 Screen Layout

The explore screen is the app's home view. It uses a full-screen map with a pull-up bottom sheet (Google Maps pattern):

- **Full-screen map** showing the player's location, nearby venues (as pins), and nearby active players in the Quick Match queue (as dots).
- **Pull-up bottom sheet** containing a mixed feed of nearby venues and open scheduled sessions, sorted by relevance. During Quick Match searching, player suggestion cards are injected into this feed (see Section 4.3).
- **Hero card overlay** positioned between the map and the top of the bottom sheet — always visible, never scrolls away. This is the primary interaction surface of the entire app.

The hero card follows the Uber "Where to?" pattern: it is the first thing the player sees, communicates the app's core purpose instantly, and transforms through the entire Quick Match lifecycle without navigating away from the explore screen.

### 2.2 Hero Card States

The hero card has six distinct visual states. Each uses a colour-coded border to signal the current phase at a glance:

| State | Border Colour | Card Content | Bottom Sheet |
|---|---|---|---|
| **1. Idle** | Blue (static) | Lightning bolt icon. Title: "Quick match". Subtitle: live player count (e.g. "3 players nearby now"). | Normal mixed feed: venues + open sessions. |
| **2. Configure** | Blue (static) | Card expands inline to show a singles/doubles toggle and a "Find a match" button. No other configuration — time window and skill preferences are pulled from the player's profile defaults. | Normal mixed feed (unchanged). |
| **3. Searching** | Blue (pulsing glow animation) | Search icon. Title: "Searching for players…" with animated dots. Countdown showing time remaining in the queue. Cancel button. | Mixed feed with player suggestion cards injected alongside venues and sessions (see Section 4.3). |
| **4. Pending request** | Blue (pulsing glow animation) | Same search animation, plus a compact banner: "Request sent to [Name]… waiting for response" with a countdown (2 min) and a "Cancel request" option. If the request resolves (accept/decline/timeout), the card returns to Searching or transitions to Confirmed. | Mixed feed (unchanged from searching state). |
| **5. Confirmed** | Green (static) | Checkmark icon. Title: "Match found!". Shows the other player's avatar, display name, skill level, sportsmanship rating, approximate distance, and a skill badge ("Great match" or "Skill mismatch — [detail]"). **Three sub-contexts:** (a) System auto-match — both players see Accept/Decline buttons with 2-min countdown. (b) Incoming manual request (recipient side) — recipient sees Accept/Decline buttons with 2-min countdown plus the requester's profile. (c) Accepted match (either path) — brief "Match confirmed!" celebration, then auto-transitions to Venue selection. | Normal mixed feed (unchanged). |
| **6. Venue selection** | Amber (static) | Map pin icon. Title: "Pick a venue". Shows top 2–3 venue suggestion cards ranked by midpoint proximity, availability, and price. Buttons: "Confirm top pick" and "See all". 15-minute countdown timer. | Normal mixed feed (unchanged). |

**After venue confirmation:** Once all players confirm a venue and payment is processed via Stripe, the hero card collapses and the player is navigated to the **Session Detail View** — a dedicated screen showing the booked session with game time, venue details, player roster, group chat, and booking receipt. The hero card on the explore screen resets to the idle state for future use.

**Doubles partial group state:** For doubles Quick Match, when a pair of 2 players has been confirmed but 2 more are still needed, the hero card enters a modified Searching state. The border remains blue (pulsing), but the card shows: "Pair formed — searching for 2 more players…" with the paired player's avatar visible and a group chat link. The pair is treated as a single unit in the queue.

> **Design Principle: The Feed Never Locks.** Throughout all hero card states, the bottom sheet feed remains browsable. The player can continue discovering venues and sessions while the Quick Match system works in the background. This prevents the explore screen from ever feeling "stuck" in a single-purpose mode.

### 2.3 Live Player Count

In the idle state, the hero card displays a live count of players currently in the Quick Match queue within the viewer's configured search radius. This count updates in real-time via WebSocket.

- The count creates urgency (e.g. "3 players nearby now") and helps the player gauge whether Quick Match is likely to find a game quickly.
- If zero players are in the queue nearby, the subtitle reads: "No players nearby — be the first!"
- The count only includes players who are actively in the Quick Match queue, not all app users.

---

## 3. Match Scoring Algorithm

Every candidate match is assigned a **composite score** used to rank suggestions in the feed and determine whether the system should auto-trigger a match. The score is a weighted sum of four factors, prioritised in the following order:

| # | Factor | Weight | How It Works |
|---|---|---|---|
| 1 | **Availability overlap** | 40% | Time window overlap between the searcher and the candidate. Measured as `overlap_minutes / searcher_window_minutes`. A candidate whose availability fully contains the searcher's window scores 1.0. Zero overlap = 0.0 (excluded). |
| 2 | **Geographic distance** | 30% | Haversine distance between the two players' GPS coordinates. Scored as `1 – (distance / max_search_radius)`. Players beyond the searcher's configured radius (e.g. 5km, 10km, 25km) score 0.0 and are excluded entirely. |
| 3 | **Player rating (sportsmanship)** | 20% | Average sportsmanship rating on a 1–5 star scale. Normalised to 0–1: `(rating – 1) / 4`. New players with no ratings default to 0.6 (equivalent of 3.4 stars) to avoid cold-start penalty. |
| 4 | **Skill level proximity** | 10% | Distance between skill tiers: Beginner = 1, Intermediate = 2, Advanced = 3. Score = `1 – (|playerA_tier – playerB_tier| / 2)`. Same tier = 1.0, adjacent tier = 0.5, two tiers apart = 0.0. |

**Composite Score** = (0.4 × Availability) + (0.3 × Distance) + (0.2 × Rating) + (0.1 × Skill)

**Auto-Match Threshold** = **0.65 (65%)**. The system will only auto-trigger a match when a candidate's composite score meets or exceeds this value. Below this threshold, the candidate still appears in the bottom sheet feed as a manual suggestion but the system will not proactively initiate a match.

> **Why is skill level the lowest weight?** Match's mission is to get people playing. In a nascent platform with a growing player base, restricting matches by skill creates dead queues and frustrated players. Skill mismatch is clearly labelled in the UI so players can make informed decisions, but the algorithm prioritises getting a game happening over getting a perfectly balanced one. This weighting can be rebalanced via admin configuration as the player base grows.

---

## 4. Quick Match — Detailed Flow

### 4.1 Entering the Queue

1. The player taps the hero card in the **idle** state.
2. The card expands inline to show a minimal configuration:
   - **Game type toggle:** Singles (2 players) or Doubles (4 players).
   - All other preferences (time window duration, preferred skill range) are pulled from the player's profile defaults. No additional configuration is required.
3. The player taps **"Find a match."**
4. The player's GPS location is captured at this moment.
5. They are placed into the **Quick Match Queue**.
6. The hero card transitions to the **Searching** state (pulsing blue border, animated dots, time remaining countdown, cancel button).

**Target:** App-open to queue-entry in under 3 seconds (2 taps).

### 4.2 Dual-Path Matching Model

Quick Match uses a dual-path model where matches can be initiated either by the system automatically or by the player manually from the feed. Both paths exist simultaneously while a player is in the searching state.

| | System Auto-Match | Manual Feed Pick |
|---|---|---|
| **Trigger** | System detects a candidate with composite score ≥ 0.65 | Player taps a suggestion card in the bottom sheet feed |
| **Timing** | Immediately — the instant a qualifying candidate enters the queue or is already present when the player joins | Any time while in the searching state |
| **Who initiates** | The system, on behalf of both players | The requesting player |
| **Confirmation type** | **Mutual:** both players are notified simultaneously and each must independently accept within 2 minutes | **One-directional:** the requester has already opted in by tapping. The recipient has 2 minutes to accept or decline. |
| **Hero card transition** | Both players' hero cards transition to the **Confirmed** state showing the other player's profile with Accept/Decline buttons | Requester's hero card transitions to **Pending request** state. If recipient accepts, both transition to **Venue selection**. |

### 4.3 Feed Suggestions While Searching

While a player is in the searching state, the bottom sheet feed is augmented with **player suggestion cards** mixed in alongside the normal venue and session results. These suggestion cards show:

- Player avatar, display name, skill level, sportsmanship rating (stars), and approximate distance.
- A **skill badge:**
  - Green **"Great match"** if the candidate falls within the player's preferred skill range (or if the player selected "Any").
  - Amber **"Skill mismatch"** with tier gap detail (e.g. "Advanced — 2 tiers above you") if outside the preferred range.
- A **"Request match"** tap target to initiate a manual match request.

**Feed behaviour:**
- The feed refreshes in **real-time** via WebSocket as new players enter the queue and existing players leave or are matched.
- Suggestion cards are sorted by composite score (highest first) and interleaved with venue/session results. Player suggestions appear near the top of the feed.
- If no candidates are currently in range, the feed shows a contextual empty card: "No players nearby yet. We'll notify you when someone joins."
- When a candidate is matched (with someone else) or leaves the queue, their card animates out of the feed.

### 4.4 Conflict Resolution: System vs. Manual

If a player has sent a **manual match request** from the feed and, while waiting for the recipient to respond, the system auto-detects a strong match (composite score ≥ 0.65) with a different player:

1. **The system match takes priority.**
2. The pending manual request is automatically cancelled.
3. The requester's hero card transitions from **Pending request** (state 4) to the **Confirmed** state (state 5) showing the system's candidate with Accept/Decline buttons.
4. The original manual request recipient's hero card returns to **Searching** (state 3) if they had opened the request. They receive a notification: "[Name]'s request was cancelled."
5. The recipient remains in the queue and is available for other matches.

> **Why does the system match win?** The system match has been scored above the quality threshold and both players are immediately available. A pending manual request is speculative — the recipient may decline or time out. Prioritising the system match maximises the probability of a confirmed game, which aligns with the core design principle of getting people playing.

### 4.5 Mutual Confirmation Flow (System Auto-Match)

When the system auto-triggers a match between two players:

1. **Both players are notified simultaneously** via push notification ("We found you a match! Tap to see."). Each player's hero card transitions to the **Confirmed** state showing the other player's profile, skill level, sportsmanship rating, distance, and a skill badge.
2. Each player sees **Accept** and **Decline** buttons with a **2-minute countdown timer**.
3. **Both players must independently accept within 2 minutes.** Neither player can see the other's decision until both have responded or the timer expires.
4. **Outcome matrix:**

| Player A | Player B | Result |
|---|---|---|
| Accept | Accept | Session created. Both removed from queue. Venue selection phase begins (see Section 4.7). |
| Accept | Decline | Match dissolved. Both returned to queue. Player B (decliner) is hidden from A's feed suggestions for **10 minutes** (cooldown). |
| Decline | Accept | Match dissolved. Both returned to queue. Player A (decliner) is hidden from B's feed suggestions for **10 minutes** (cooldown). |
| Decline | Decline | Match dissolved. Both returned to queue. Mutual **10-minute cooldown** applied (hidden from each other). |
| Accept | Timeout | Treated as a **soft decline** by B. Both returned to queue. **No cooldown** applied (B may not have seen the notification). |
| Timeout | Accept | Treated as a **soft decline** by A. Both returned to queue. **No cooldown** applied. |
| Decline | Timeout | Match dissolved. Both returned to queue. Player A (decliner) hidden from B for **10 minutes**. **No cooldown** on B (timeout is not a deliberate action). |
| Timeout | Decline | Match dissolved. Both returned to queue. Player B (decliner) hidden from A for **10 minutes**. **No cooldown** on A. |
| Timeout | Timeout | Both returned to queue. **No cooldown** applied to either player. |

**Locking during any confirmation flow:** A player can only be in one confirmation flow at a time. This applies to system auto-match mutual confirmations AND to recipients viewing an incoming manual request. While in any confirmation flow:
- No new system auto-matches are triggered for that player.
- They cannot send manual requests from the feed.
- They cannot receive new manual requests from other players.
- Incoming manual requests from other players are silently queued and delivered after the confirmation resolves.

### 4.6 Manual Request Flow (Feed Pick)

When a player taps "Request match" on a suggestion card in the feed:

1. A match request is sent to the recipient. The requester's hero card transitions to **Pending request** state (state 4: pulsing blue, "Request sent to [Name]… waiting for response", 2-minute countdown, cancel option).
2. The recipient receives a push notification: "[Name] wants to play with you! Tap to respond."
3. The recipient's hero card transitions to the **Confirmed** state (state 5, incoming request sub-context: green border, requester's profile with avatar/skill/rating/distance, Accept and Decline buttons, 2-minute countdown).
4. **A player can only have one outgoing manual request at a time.** They cannot send requests to multiple candidates simultaneously.
5. **Outcomes:**

| Recipient action | Requester hero card | Recipient hero card | Result |
|---|---|---|---|
| **Accept** | Transitions to **Venue selection** (state 6) | Transitions to **Venue selection** (state 6) | Session created (singles) or pair formed (doubles). Both removed from queue. Venue selection begins. |
| **Decline** | Returns to **Searching** (state 3) | Returns to **Searching** (state 3) | Requester back in queue. Recipient stays in queue. Recipient hidden from requester's feed for **10 minutes**. |
| **Timeout (2 min)** | Returns to **Searching** (state 3) | Returns to **Searching** (state 3) | Treated as a soft decline. Requester back in searching state. No cooldown applied. |

**Note:** While a manual request is pending, the system may still auto-match the requester with a different player if a candidate above the 0.65 threshold is found. In this case, the system match takes priority (see Section 4.4).

**Manual cancellation by requester:** If the requester taps "Cancel request" in the Pending request state before the recipient responds:
- The requester's hero card returns to **Searching** (state 3).
- The recipient's hero card returns to **Searching** (state 3) if they had opened the request, or the push notification is silently withdrawn.
- The recipient receives a notification: "[Name]'s request was cancelled."
- No cooldown is applied to either player.

### 4.7 Venue Selection Phase (Post-Match)

Once all player slots are filled (via either matching path), the system automatically suggests venues. The hero card transitions to the **Venue selection** state (amber border).

**Venue ranking criteria (in order):**
1. **Geographic midpoint** between all matched players — closest venues to the midpoint ranked higher.
2. **Court availability** — only venues with courts available during the agreed time window are shown.
3. **Price** — lowest hourly rate used as a tiebreaker.

**Venue selection flow:**
1. The system presents the **top 3 venue suggestions** as compact cards within the hero card area. The top-ranked venue is marked "Best match."
2. **Any player** can tap "Confirm" on a venue. This triggers a confirmation prompt sent to all other players in the session.
3. Each other player has **5 minutes** to confirm or suggest an alternative from the list.
4. Once all players confirm the same venue, the **booking checkout flow** begins:
   - Court and time slot are reserved.
   - Upsell items are presented (per merchant configuration).
   - Payment is processed via Stripe (total cost split evenly among all players).
   - Confirmation is sent to all players and the merchant.
5. After checkout completes, the hero card collapses and the player is navigated to the **Session Detail View**.

> **Venue confirmation timeout: 15 minutes.** If no venue is confirmed by all players within 15 minutes of the match being formed, the session is auto-cancelled. All players are returned to the Quick Match Queue (their time window continues, not reset) and receive a notification: "Your match expired because a venue wasn't confirmed in time. We've put you back in the queue."

### 4.8 Queue Expiry

A player's Quick Match queue entry expires when their configured time window elapses (pulled from profile defaults, e.g. "next 2 hours"). Upon expiry:

- The player receives a push notification: "Your Quick Match window has ended. No match was found this time."
- The hero card returns to the **idle** state.
- The player's dot is removed from the map for other players.
- They can immediately re-enter the queue by tapping the hero card again.

---

## 5. Schedule Match — Detailed Flow

### 5.1 Session Creation

A player creates a scheduled session by configuring:

- **Date and time** of the game.
- **Game type:** Singles (2 players) or Doubles (4 players).
- **Preferred skill range:** e.g. Beginner–Intermediate, or "Any".
- **Venue:** Optional — can attach a venue now during creation, or leave it open for later.
- **Auto-accept toggle:** Whether join requests need manual approval from the creator or are automatically accepted.

The session enters the **"Open"** state and appears in the bottom sheet feed for nearby players whose skill level and location fall within the session's criteria.

### 5.2 Lobby & Join Requests

While a session is "Open":

- Nearby matching players see it in their bottom sheet feed, sorted by composite match score relative to the session's parameters.
- Players can tap **"Request to Join."** If auto-accept is enabled, they are added immediately. Otherwise, the session creator receives a push notification and can approve or decline.
- The session creator can **share a direct link** to the session for inviting specific people.
- All joined players see a **lobby view** with the current roster, game details, and a group chat (auto-created when the first player joins).

### 5.3 Auto-Fill System

The auto-fill system acts as a safety net to prevent sessions from dying due to unfilled slots.

> **Auto-fill trigger condition:** Auto-fill activates when a session is **1 hour before its scheduled start time** AND has **at least 50% of its slots filled** (e.g. 1/2 for singles, 2/4 for doubles) but is not yet full.

When triggered, the system identifies candidates from the **broader player pool** (not limited to the Quick Match queue) based on:

- Players who have set availability windows in their profile that overlap with the session's time.
- Players within the session's geographic area (based on the session location or creator's location).
- Ranked by composite match score using the same algorithm as Quick Match (Section 3).

**There is no skill boundary restriction for auto-fill candidates.** Any available player within range can be invited. However, the system clearly labels any skill mismatch in the invitation notification:

| Skill Gap | Invitation Label |
|---|---|
| Same tier as session preference | "Great fit — this session matches your skill level." |
| 1 tier outside preference | "Slightly outside your usual range — session is looking for [X] level players. You're [Y]." |
| 2 tiers outside preference | "Skill gap heads-up — this session is [X] level. You're [Y]. Still up for it?" |

### 5.4 Auto-Fill Opt-In Flow

Auto-filled players are **never placed into a session without consent**. The flow is:

1. The highest-ranked candidate receives a push notification: "A nearby session needs one more player! [Session details]. Want to join?"
2. The candidate has **10 minutes** to accept or decline.
3. If they **accept**, they are added to the session and the lobby updates for all players.
4. If they **decline or time out**, the next-ranked candidate is invited.

**Sequential invitations only:** The system invites candidates one at a time (not in parallel) to avoid over-filling a session. Each invitation must resolve (accept, decline, or timeout) before the next candidate is contacted.

**If all candidates are exhausted** and the session is still not full at start time, the existing players are notified and the session creator can choose to:
- **Proceed** with fewer players than originally planned.
- **Cancel** the session (all players notified, any venue bookings refunded per the refund policy).

---

## 6. Unified Session Lifecycle

Both Quick Match and Schedule Match sessions share the same lifecycle states. The transitions differ depending on the mode of creation:

| State | Quick Match | Schedule Match |
|---|---|---|
| **Searching** | Player is in the Quick Match Queue. Hero card is in "Searching" state. Feed shows player suggestions. | N/A — session is created directly as Open. |
| **Open** | N/A — Quick Match skips this state. | Session is visible in the feed, accepting join requests. |
| **Confirming** | Mutual confirmation in progress (system auto-match: both have 2 min) or manual request pending (recipient has 2 min). | N/A — join requests handle player acceptance. |
| **Matched** | All player slots filled. Awaiting venue confirmation (15 min timeout). Hero card in Venue selection state. | All player slots filled (manually or via auto-fill). Awaiting game time. |
| **Booked** | Venue confirmed, payment processed. Awaiting game time. Player navigated to Session Detail View. | Venue confirmed, payment processed. Awaiting game time. |
| **In Progress** | Game is happening (triggered automatically at the booked start time). | Game is happening (triggered automatically at the booked start time). |
| **Completed** | Game finished. All players prompted to rate the venue (1–5 stars + optional review) and rate each other player (1–5 stars for sportsmanship). | Game finished. Same rating/review prompts. |
| **Cancelled** | Venue timeout expired, mutual confirmation failed, player cancelled pre-booking, or queue expired. | Creator cancelled, or session not filled and creator chose not to proceed. Refund policy applies if venue was booked. |

---

## 7. Edge Cases & Error Handling

### 7.1 Player Drops Out After Match (Pre-Booking)

If a player leaves a Quick Match session **before venue confirmation** (i.e. during the Venue selection phase):

- The remaining player(s) are returned to the Quick Match Queue with **priority placement** (their existing time window continues from where it was, not reset).
- Their hero card returns to the **Searching** state.
- They receive a notification: "A matched player left. We've put you back in the queue."

### 7.2 Player Drops Out After Booking

If a player cancels **after a venue has been booked** but before the configured refund cutoff time:

- The refund policy applies per the Payments specification.
- Remaining players are notified: "A player left. We're looking for a replacement."
- The session enters a special **"Open (Backfill)"** state where the system attempts to find a replacement player using the same auto-fill mechanism described in Section 5.3–5.4.
- If no replacement is found by game time, remaining players are notified and the session creator decides whether to proceed or cancel.

### 7.3 Doubles — Partial Group Matching

For doubles (4-player) Quick Match, the system supports **partial group formation**:

1. When 2 players are matched via mutual confirmation (or manual request acceptance), they form a **pair**.
2. The pair remains in the Quick Match Queue as a **single unit**.
3. The hero card enters the modified searching state: "Pair formed — searching for 2 more players…" with the paired player's avatar visible.
4. A **group chat** is created for the pair while they wait.
5. The system looks for either **2 individual players** or **another already-formed pair** to complete the group of 4.
6. When a second pair or two individuals are found, mutual confirmation proceeds between the groups.
7. Once all 4 slots are filled and confirmed, the venue selection phase begins.

### 7.4 No Candidates Available

If a Quick Match player enters the queue and there are **zero other players in range**:

- The hero card shows the Searching state normally (pulsing blue border, countdown timer).
- The feed shows a contextual empty card: "No players nearby right now. We'll notify you as soon as someone is looking to play."
- The system sends a **push notification** if a candidate enters the queue while the player's window is still active: "Someone nearby wants to play! Open Match to see."

### 7.5 Concurrent Request Handling

A player can only be in **one confirmation flow at a time.** While a player is viewing a match (whether system auto-match or accepted manual request), they cannot:

- Send additional manual requests from the feed.
- Be auto-matched by the system with a different player.
- Receive new manual requests from other players (incoming requests are silently queued and delivered after the confirmation resolves).

**Exception — pending manual request:** If a player has an outgoing manual request that has not yet been responded to, they are still in the Searching state (not locked in a confirmation). The system **may** auto-match them with a different player during this window. If it does, the system match takes priority and the pending manual request is cancelled (see Section 4.4).

### 7.6 Simultaneous System Match Candidates

If the system identifies a mutual match between Player A and Player B at the same time that another strong candidate (Player C) also qualifies for A:

- The system sends the **first qualifying match** (A ↔ B) and holds C in the pool.
- Player A is now locked in a confirmation (see Section 7.5), so C cannot be matched with A.
- If A ↔ B fails during mutual confirmation (decline or timeout), A is returned to the queue and may then be matched with C on the next scan.

### 7.7 Player Closes the App While in Queue

If a player closes the app or loses connection while in the Quick Match Queue:

- Their queue entry **persists** for up to 5 minutes of inactivity (configurable).
- If they reopen the app within 5 minutes, the hero card restores to the Searching state with the remaining time.
- If they do not return within 5 minutes, they are silently removed from the queue. On next app open, the hero card is in the idle state.
- If a system auto-match is triggered while the player is backgrounded, they receive a push notification. The 2-minute mutual confirmation timer begins when the notification is sent, not when the player opens it.

### 7.8 Venue Selection Disagreement

If, during the venue selection phase, players cannot agree on a venue:

- Any player can tap "See all" to browse additional venues beyond the top 3 suggestions.
- If a player confirms a venue but another player rejects it, the rejecting player can propose an alternative. The original confirmer is then asked to confirm the alternative.
- The 15-minute overall timeout still applies. If no consensus is reached within 15 minutes, the session is cancelled and all players are returned to the queue (see Section 4.7).

---

## 8. Matching-Related Notifications

| Event | Message | Recipients |
|---|---|---|
| System auto-match found | "We found you a match! Tap to see." | Both matched players |
| Manual match request received | "[Name] wants to play with you! Tap to respond." | Request recipient |
| Manual match request cancelled by requester | "[Name]'s request was cancelled." | Request recipient |
| Manual match request cancelled by system | "[Name]'s request was cancelled." | Original request recipient |
| Mutual confirmation — both accepted | "It's on! [Name] accepted. Time to pick a venue." | Both players |
| Mutual confirmation — other player declined | "[Name] isn't available right now. Searching for more matches…" | Remaining player |
| Mutual confirmation — other player timed out | "No response from [Name]. Back to searching…" | Remaining player |
| Venue suggestions ready | "We found 3 great courts near you. Pick one!" | All matched players |
| Venue confirmed by another player | "[Name] picked [Venue]. Confirm?" | Other players in session |
| Venue confirmation timeout | "Match expired — no venue confirmed in time. Back in the queue." | All matched players |
| Booking confirmed | "You're booked! [Venue] at [Time]. See you there." | All players + merchant |
| Quick Match window expired | "Your Quick Match window has ended. No match this time." | Queued player |
| New candidate enters empty queue | "Someone nearby wants to play! Open Match to see." | Queued player with no prior candidates |
| Auto-fill invitation | "A nearby session needs you! [Details]. Want to join?" | Auto-fill candidate |
| Session join request (Schedule Match) | "[Name] wants to join your session." | Session creator |
| Session full | "Your session is full! All players confirmed." | All session players |
| Player dropped — backfill initiated | "A player left. We're looking for a replacement." | Remaining session players |
| Player dropped — backfill found | "Great news — [Name] is joining as a replacement." | Remaining session players |
| App backgrounded during queue | "You're still in the Quick Match queue. [X] min remaining." | Backgrounded player (after 2 min) |

---

## 9. Timing Constants Reference

All configurable timeouts and durations in one place for easy tuning post-launch:

| Parameter | Default Value | Configurable? |
|---|---|---|
| System auto-match score threshold | 0.65 (65%) | Yes (admin) |
| Mutual confirmation window (per player, simultaneous) | 2 minutes | Yes (admin) |
| Manual request acceptance window | 2 minutes | Yes (admin) |
| Venue confirmation timeout (total, post-match) | 15 minutes | Yes (admin) |
| Individual venue confirm window (per player after someone picks) | 5 minutes | Yes (admin) |
| Decline cooldown (hide declined player from requester's feed) | 10 minutes | Yes (admin) |
| Auto-fill activation trigger (time before session start) | 1 hour | Yes (admin) |
| Auto-fill minimum fill rate to trigger | 50% of slots | Yes (admin) |
| Auto-fill candidate response window | 10 minutes | Yes (admin) |
| Quick Match queue max duration | Player-configured (1–4 hours) | Player-set (via profile) |
| App backgrounded queue persistence | 5 minutes | Yes (admin) |
| One outgoing manual request at a time | 1 | Fixed (not configurable) |

---
